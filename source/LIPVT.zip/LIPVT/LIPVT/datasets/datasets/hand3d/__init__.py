# Copyright (c) OpenMMLab. All rights reserved.
from .interhand_3d_dataset import InterHand3DDataset

__all__ = ['InterHand3DDataset']
