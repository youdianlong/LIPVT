import cv2
import numpy as np

from mmpose.datasets.builder import PIPELINES


@PIPELINES.register_module()
class simDR:
    """
    simDR的数据预处理部分
    """
    pass