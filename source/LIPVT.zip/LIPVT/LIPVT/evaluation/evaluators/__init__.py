# Copyright (c) OpenMMLab. All rights reserved.
from .mutli_dataset_evaluator import MultiDatasetEvaluator

__all__ = ['MultiDatasetEvaluator']
