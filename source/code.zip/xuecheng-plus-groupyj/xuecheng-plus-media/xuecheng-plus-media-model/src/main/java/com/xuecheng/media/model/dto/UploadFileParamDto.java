package com.xuecheng.media.model.dto;

import lombok.Data;

@Data
public class UploadFileParamDto {
    private String fileName;
    private String fileType;
    private Long fileSize;
    private String tags;
    private String username;
    private String remark;
}
