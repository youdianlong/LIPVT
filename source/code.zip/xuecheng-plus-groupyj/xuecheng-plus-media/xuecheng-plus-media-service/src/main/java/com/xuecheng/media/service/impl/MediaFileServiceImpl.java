package com.xuecheng.media.service.impl;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.common.collect.HashBiMap;
import com.j256.simplemagic.ContentInfo;
import com.j256.simplemagic.ContentInfoUtil;
import com.xuecheng.base.exception.XueChengPlusException;
import com.xuecheng.base.model.PageParams;
import com.xuecheng.base.model.PageResult;
import com.xuecheng.base.model.RestResponse;
import com.xuecheng.media.mapper.MediaFilesMapper;
import com.xuecheng.media.mapper.MediaProcessHistoryMapper;
import com.xuecheng.media.mapper.MediaProcessMapper;
import com.xuecheng.media.model.dto.QueryMediaParamsDto;
import com.xuecheng.media.model.dto.UploadFileParamDto;
import com.xuecheng.media.model.dto.UploadFileResultDto;
import com.xuecheng.media.model.po.MediaFiles;
import com.xuecheng.media.model.po.MediaProcess;
import com.xuecheng.media.service.MediaFileService;
import io.minio.*;
import io.minio.messages.DeleteError;
import io.minio.messages.DeleteObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.compress.utils.IOUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.*;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @author Mr.M
 * @version 1.0
 * @description TODO
 * @date 2022/9/10 8:58
 */
@Slf4j
@Service
public class MediaFileServiceImpl implements MediaFileService {

    @Autowired
    MediaFilesMapper mediaFilesMapper;
    @Autowired
    MediaProcessMapper processMapper;
    @Autowired
    MediaFileService mediaFileService;
    @Autowired
    MinioClient minioClient;
    @Autowired
    MediaProcessMapper mediaProcessMapper;
    @Autowired
    MediaProcessHistoryMapper mediaProcessHistoryMapper;
//    MinioClient minioClient =
//            MinioClient.builder()
//                    .endpoint("http://192.168.101.65:9000") //Minio地址+服务端口
//                    .credentials("minioadmin", "minioadmin")//用户名+密码
//                    .build();
    //存储普通文件
    @Value("${minio.bucket.files}")
    private String bucketName_mediafiles;
    //存储视频文件
    @Value("${minio.bucket.videofiles}")
    private String bucketName_vediofiles;

    @Override
    public PageResult<MediaFiles> queryMediaFiels(Long companyId, PageParams pageParams, QueryMediaParamsDto queryMediaParamsDto) {

        //构建查询条件对象
        LambdaQueryWrapper<MediaFiles> queryWrapper = new LambdaQueryWrapper<>();

        //分页对象
        Page<MediaFiles> page = new Page<>(pageParams.getPageNo(), pageParams.getPageSize());
        // 查询数据内容获得结果
        Page<MediaFiles> pageResult = mediaFilesMapper.selectPage(page, queryWrapper);
        // 获取数据列表
        List<MediaFiles> list = pageResult.getRecords();
        // 获取数据总数
        long total = pageResult.getTotal();
        // 构建结果集
        PageResult<MediaFiles> mediaListResult = new PageResult<>(list, total, pageParams.getPageNo(), pageParams.getPageSize());
        return mediaListResult;

    }

    //根据扩展名获取mimeType
    private String getMimeType(String extension) {
        if (extension == null) {
            extension = "";
        }
        ContentInfo extensionMatch = ContentInfoUtil.findExtensionMatch(extension);
        String mimeType = MediaType.APPLICATION_OCTET_STREAM_VALUE;//通用mimeType 字节流
        if(extensionMatch != null) {
            mimeType = extensionMatch.getMimeType();
        }
        return mimeType;
    }

    //根据当前时间设置文件默认存储目录路径 年/月/日/
    private String getDefaultFolderPath(){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String fold = sdf.format(new Date()).replace("-", "/")+"/";
        return fold;
    }

    //获取文件的md5值
    private String getFileMd5(File file){
        try(FileInputStream fis = new FileInputStream(file)) {
            String fileMd5 = DigestUtils.md5Hex(fis);
            return fileMd5;
        }  catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    //将文件上传到minio
    public boolean addMediaFilesToMinIO(String localFilePath, String bucket,String objectName,String mimeType){
        try {
            UploadObjectArgs testbucket = UploadObjectArgs.builder()
                    .bucket(bucket)//桶
                    .object(objectName)//对象名
                    .filename(localFilePath)//指定本地文件路径
                    .contentType(mimeType)//文件类型
                    .build();
            minioClient.uploadObject(testbucket);
            log.debug("上传文件到minio成功，bucket={},objectName={}",bucket,objectName);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            log.error("上传文件出错,bucket={},objectName={},错误信息={}",bucket,objectName,e.getMessage());
        }
        return false;
    }

    @Override
    public MediaFiles getFileById(String id) {
        MediaFiles mediaFiles = mediaFilesMapper.selectById(id);
        return mediaFiles;
    }

    @Transactional
    public MediaFiles addMediaFilesToDB(Long companyId,String objectName,String fileMd5,UploadFileParamDto uploadFileParamDto,String bucket){
        //将文件信息保存到数据库（事务控制）
        MediaFiles mediaFiles = mediaFilesMapper.selectById(fileMd5);
        if (mediaFiles==null){
            mediaFiles = new MediaFiles();
            BeanUtils.copyProperties(uploadFileParamDto,mediaFiles);
            //文件id
            mediaFiles.setId(fileMd5);
            //机构id
            mediaFiles.setCompanyId(companyId);
            mediaFiles.setBucket(bucket);
            mediaFiles.setFilePath(objectName);
            mediaFiles.setFileId(fileMd5);
            mediaFiles.setUrl("/"+bucket+"/"+objectName);
            mediaFiles.setCreateDate(LocalDateTime.now());
            mediaFiles.setFilename(uploadFileParamDto.getFileName());
            //资源状态
            mediaFiles.setStatus("1");
            //审核状态
            mediaFiles.setAuditStatus("002003");
            int insert = mediaFilesMapper.insert(mediaFiles);
            if (insert<=0){
                log.debug("向数据库保存文件信息失败，objectName:{}",objectName);
                return null;
            }
            //同时需要记录待处理的任务,向MediaProcess插入记录
            addWaitingTask(mediaFiles);
            //如果是avi视频则写入待处理任务

        }
        return mediaFiles;
    }

    //添加待处理任务
    private void addWaitingTask(MediaFiles mediaFiles){
        //先获取文件的mimetype
        String filename = mediaFiles.getFilename();
        String extension = filename.substring(filename.lastIndexOf("."));
        String mimeType = getMimeType(extension);
        if (mimeType.equals("video/x-msvideo")){
            //如果是avi文件，则需要写入待处理表
            MediaProcess mediaProcess = new MediaProcess();
            BeanUtils.copyProperties(mediaFiles,mediaProcess);
            //状态是未处理
            mediaProcess.setStatus("1");
            mediaProcess.setCreateDate(LocalDateTime.now());
            mediaProcess.setFailCount(0);
            //最终互联网上访问的url
            mediaProcess.setUrl(null);
            mediaProcessMapper.insert(mediaProcess);
        }

    }


    //首先检查文件是否上传成功
    @Override
    public RestResponse<Boolean> checkFile(String fileMd5) {
        //查询数据库
        MediaFiles mediaFiles = mediaFilesMapper.selectById(fileMd5);
        if (mediaFiles!=null){
            //如果数据库存在，再查询minio
            GetObjectArgs getObjectArgs = GetObjectArgs
                    .builder()
                    .bucket(mediaFiles.getBucket())
                    .object(mediaFiles.getFilePath())
                    .build();
            try {
                FilterInputStream inputStream = minioClient.getObject(getObjectArgs);
                if (inputStream!=null){
                    return RestResponse.success(true);
                }
            } catch (Exception e) {
                e.printStackTrace();

            }
        }
        return RestResponse.success(false);
    }

    private String getChunkFileFolderPath(String fileMd5){
        return fileMd5.substring(0,1)+"/"+fileMd5.substring(1,2)+"/"+fileMd5+"/"+"chunk"+"/";
    }
    //接着再去查分块
    @Override
    public RestResponse<Boolean> checkChunk(String fileMd5, int chunkIndex) {
        //分块的存储路径为MD5的前两位为两个目录，chunk存储分块文件
        String filePath = getChunkFileFolderPath(fileMd5);

        GetObjectArgs getObjectArgs = GetObjectArgs
                .builder()
                .bucket(bucketName_vediofiles)
                .object(filePath+chunkIndex)
                .build();
        try {
            FilterInputStream inputStream = minioClient.getObject(getObjectArgs);
            if (inputStream!=null){
                return RestResponse.success(true);
            }
        } catch (Exception e) {
            e.printStackTrace();

        }
        return RestResponse.success(false);
    }

    @Override
    public RestResponse uploadChunk(String fileMd5, int chunkIndex, String localFilePath) {
        String mimeType = getMimeType(null);
        //将分块文件上传到minio
        boolean b = addMediaFilesToMinIO(localFilePath, bucketName_vediofiles, getChunkFileFolderPath(fileMd5) + chunkIndex, mimeType);
        if (!b){
            return RestResponse.validfail(false,"上传分块文件失败");
        }
        return RestResponse.success(true);
    }

    //得到合并后的文件地址
    private String getFilePathMd5(String fileMd5,String extension){
        return fileMd5.substring(0,1)+"/"+fileMd5.substring(1,2)+"/"+fileMd5+"/"+fileMd5+"/"+fileMd5+extension;
    }

    @Override
    public RestResponse mergeChunks(Long companyId, String fileMd5, int chunkTotal, UploadFileParamDto uploadFileParamDto) {
        String chunkFileFolderPath = getChunkFileFolderPath(fileMd5);
        //找到分块文件调用minio的sdk进行文件合并
        List<ComposeSource> collect = Stream.iterate(0, i -> ++i).limit(chunkTotal).map(i -> ComposeSource.builder().bucket(bucketName_vediofiles).object(chunkFileFolderPath + i).build()).collect(Collectors.toList());
        //先拿到源文件名称
        String fileName = uploadFileParamDto.getFileName();
        String extension = fileName.substring(fileName.lastIndexOf("."));
        String objectName = getFilePathMd5(fileMd5, extension);
        ComposeObjectArgs build = ComposeObjectArgs.builder()
                .bucket(bucketName_vediofiles)
                .object(objectName)
                .sources(collect)
                .build();
        //合并文件
        try {
            minioClient.composeObject(build);
        } catch (Exception e) {
            log.error("合并文件出错，bucket:{},objectName:{},错误信息:{}",bucketName_vediofiles,objectName,e.getMessage());
            return RestResponse.validfail(false,"合并文件出错");
        }
        //合并之后检验是否和源文件信息一致，一致视频上传才成功
        //先下载文件,验证下载文件会前端的请求会超时，关闭
//        File file = downloadFileFromMinIO(bucketName_vediofiles,objectName);
//        //计算合并后文件的md5
//        try(FileInputStream fileInputStream = new FileInputStream(file)){
//            String mergeFile = DigestUtils.md5Hex(fileInputStream);
//            //比较原始的md5值和合并后的md5值
//            if(!mergeFile.equals(fileMd5)){
//                log.error("检验合并文件md5值不一致，原始文件:{}，合并文件:{}",fileMd5,mergeFile);
//                return RestResponse.validfail(false,"文件检验失败");
//            }
//            uploadFileParamDto.setFileSize(file.length());
//        }catch (Exception e){
//            e.printStackTrace();
//            return RestResponse.validfail(false,"文件检验失败");
//        }
        //将文件信息入库,这里非事务方法调用事务方法，需要用代理对象对调用
        MediaFiles mediaFiles = mediaFileService.addMediaFilesToDB(companyId, objectName, fileMd5, uploadFileParamDto, bucketName_vediofiles);
        if (mediaFiles==null){
            return RestResponse.validfail(false,"文件入库失败");
        }
        //清理分块文件
        clearChunkFiles(chunkFileFolderPath,chunkTotal);

        return RestResponse.success(true);
    }



    private void clearChunkFiles(String chunkFileFolderPath,int chunkTotal){
        Iterable<DeleteObject> objects = Stream.iterate(0,i->++i).limit(chunkTotal).map(i->new DeleteObject(chunkFileFolderPath+i)).collect(Collectors.toList());
        RemoveObjectsArgs build = RemoveObjectsArgs.builder().bucket(bucketName_vediofiles).objects(objects).build();
        Iterable<Result<DeleteError>> results = minioClient.removeObjects(build);
        results.forEach(r->{
            try {
                DeleteError deleteError = r.get();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

    }

    /**
     * 从minio下载文件
     * @param bucket 桶
     * @param objectName 对象名称
     * @return 下载后的文件
     */
    public File downloadFileFromMinIO(String bucket,String objectName){
        //临时文件
        File minioFile = null;
        FileOutputStream outputStream = null;
        try{
            InputStream stream = minioClient.getObject(GetObjectArgs.builder()
                    .bucket(bucket)
                    .object(objectName)
                    .build());
            //创建临时文件
            minioFile=File.createTempFile("minio", ".merge");
            outputStream = new FileOutputStream(minioFile);
            IOUtils.copy(stream,outputStream);
            return minioFile;
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            if(outputStream!=null){
                try {
                    outputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    //    @Transactional
    @Override
    public UploadFileResultDto uploadFile(Long companyId, UploadFileParamDto uploadFileParamDto, String localFilePath,String objectName) {
        //在进行事务控制的时候，涉及到访问网络资源，不要加数据库的事务控制注解Transactional,因为网络链接不稳定，可能导致该线程占用数据库链接的时间较长，极端情况下，会出现数据库资源不够用
        //可以选择直接在访问数据库的方法上加上Transactional注解，以达到优化的目的
        //要将文件上床到minio，分为以下几个步骤
        //1、得到文件名
        String fileName = uploadFileParamDto.getFileName();
        //2、获取文件的扩展名
        String extension = fileName.substring(fileName.lastIndexOf("."));
        //3、得到文件的mimeType类型
        String mimeType = getMimeType(extension);
        //4、获取文件的md5值
        String fileMd5 = getFileMd5(new File(localFilePath));
        //5、获取文件的目录
        String defaultFolderPath = getDefaultFolderPath();
        //如果传入了objectname参数，就按objectname的路径去存储，否则由MD5值初始化objectName
        if(objectName==null) {
            objectName = defaultFolderPath + fileMd5 + extension;
        }
        //上传文件
        boolean result = addMediaFilesToMinIO(localFilePath, bucketName_mediafiles, objectName, mimeType);
        if(!result){
            XueChengPlusException.cast("上传文件失败");
        }


        /*
        注意：出发点：缩短事务的方法，提高系统性能
        问题来了：只有代理对象执行加了Transactional注解的方法，事务才能被控制，否则都不能被控制(事务失效问题，非事务方法调用事务方法)
        解决方案：将当前Service注入进来，注入来的对象都是代理对象，用注入的对象调用事务控制的方法即可
         */
        MediaFiles mediaFiles = mediaFileService.addMediaFilesToDB(companyId, objectName, fileMd5, uploadFileParamDto, bucketName_mediafiles);
        if (mediaFiles==null){
            XueChengPlusException.cast("文件上传后保存文件信息失败");
        }
        //准备返回的对象
        UploadFileResultDto uploadFileResultDto = new UploadFileResultDto();
        BeanUtils.copyProperties(mediaFiles,uploadFileResultDto);
        return uploadFileResultDto;
    }
}
