package com.xuecheng.media.service;

import com.xuecheng.base.model.PageParams;
import com.xuecheng.base.model.PageResult;
import com.xuecheng.base.model.RestResponse;
import com.xuecheng.media.model.dto.QueryMediaParamsDto;
import com.xuecheng.media.model.dto.UploadFileParamDto;
import com.xuecheng.media.model.dto.UploadFileResultDto;
import com.xuecheng.media.model.po.MediaFiles;

import java.io.File;

/**
 * @author Mr.M
 * @version 1.0
 * @description 媒资文件管理业务类
 * @date 2022/9/10 8:55
 */
public interface MediaFileService {

    /**
     * @param pageParams          分页参数
     * @param queryMediaParamsDto 查询条件
     * @return com.xuecheng.base.model.PageResult<com.xuecheng.media.model.po.MediaFiles>
     * @description 媒资文件查询方法
     * @author Mr.M
     * @date 2022/9/10 8:57
     */
    public PageResult<MediaFiles> queryMediaFiels(Long companyId, PageParams pageParams, QueryMediaParamsDto queryMediaParamsDto);

    public UploadFileResultDto uploadFile(Long companyId, UploadFileParamDto uploadFileParamDto,String localFilePath,String objectName);

    MediaFiles addMediaFilesToDB(Long companyId, String objectName, String fileMd5, UploadFileParamDto uploadFileParamDto, String bucketNameMediafiles);

    RestResponse<Boolean> checkFile(String fileMd5);

    RestResponse<Boolean> checkChunk(String fileMd5,int chunkIndex);

    RestResponse uploadChunk(String fileMd5,int chunkIndex,String localFilePath);

    RestResponse mergeChunks(Long companyId,String fileMd5,int chunkTotal,UploadFileParamDto uploadFileParamDto);

    /*
     * @Description: 从minio中下载文件
     * @param bucket 指定minio中的桶
     * @param objectName 指定minio中的文件路径
     * @return java.io.File
     * @Author: yujie
     * @Date: 2024/9/20 16:37
     */
    File downloadFileFromMinIO(String bucket, String objectName);

    boolean addMediaFilesToMinIO(String localFilePath, String bucket,String objectName,String mimeType);

    /*
     * @Description: 根据媒资的id去查询文件的信息
     * @param id
     * @return com.xuecheng.media.model.po.MediaFiles
     * @Author: yujie
     * @Date: 2024/9/22 19:06
     */
    MediaFiles getFileById(String id);

}
