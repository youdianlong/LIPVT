package com.xuecheng.media.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xuecheng.media.model.po.MediaProcess;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author itcast
 */
public interface MediaProcessMapper extends BaseMapper<MediaProcess> {

    @Select("select * from xcdemo_media.media_process t where t.id % #{shardTotal} = #{shardIndex} and (t.status=1 or t.status=3) and t.fail_count<3 limit #{count}")
    List<MediaProcess> selectListBySharedIndex(@Param("shardTotal")int shardTotal,@Param("shardIndex")int shardIndex,@Param("count")int count);

    /*
     * @Description: 开启一个任务(利用数据库去抢锁)
     * 去更新待处理任务表中的状态字段为处理中，哪个线程更新成功，则锁由哪个线程抢到。（由数据库实现的乐观锁）
     * @param id
     * @return int
     * @Author: yujie
     * @Date: 2024/9/20 15:19
     */
    @Update("update xcdemo_media.media_process m set m.status='4' where (m.status='1' or m.status='3') and m.fail_count<3 and m.id=#{id}")
    int startTask(@Param("id") long id);

}
