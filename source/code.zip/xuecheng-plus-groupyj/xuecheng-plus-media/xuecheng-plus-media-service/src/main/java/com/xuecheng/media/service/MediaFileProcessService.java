package com.xuecheng.media.service;

import com.xuecheng.media.model.po.MediaProcess;

import java.util.List;

/*
 * @Description:
 * @param null
 * @return 视频处理
 * @Author: yujie
 * @Date: 2024/9/20 10:51
 */
public interface MediaFileProcessService {
    public List<MediaProcess> getMediaProcessList(int shardTotal,int shardIndex,int count);

    /*
     * @Description: 开启任务
     * @param id
     * @return boolean
     * @Author: yujie
     * @Date: 2024/9/20 15:25
     */
    public boolean startTask(Long id);

    /*
     * @Description: 更新任务处理的结果
     * @param taskId
     * @param status
     * @param fileId
     * @param url
     * @param errorMsg
     * @return void
     * @Author: yujie
     * @Date: 2024/9/20 15:30
     */
    void saveProcessFinishStatus(Long taskId,String status,String fileId,String url,String errorMsg);

}
