package com.xuecheng.media.service.jobhandler;

import com.xuecheng.base.utils.Mp4VideoUtil;
import com.xuecheng.media.mapper.MediaProcessMapper;
import com.xuecheng.media.model.po.MediaProcess;
import com.xuecheng.media.service.MediaFileProcessService;
import com.xuecheng.media.service.MediaFileService;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.omg.SendingContext.RunTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/*
 * @Description: 视频处理任务
 * @param null
 * @return
 * @Author: yujie
 * @Date: 2024/9/20 15:59
 */
@Slf4j
@Component
public class VideoTask {
    //得到ffmpeg程序的路径
    @Value("${videoprocess.ffmpegpath}")
    private String ffmpegPath;

    @Autowired
    MediaFileProcessService mediaFileProcessService;
    @Autowired
    MediaFileService mediaFileService;

    @XxlJob("videoJobHandler")
    public void shardingJobHandler() throws Exception {

        // 分片参数
        int shardIndex = XxlJobHelper.getShardIndex();
        int shardTotal = XxlJobHelper.getShardTotal();

        //确定CPU核心数
        int processors = Runtime.getRuntime().availableProcessors();
        //首先拿到分片参数，查询待处理的任务，每个核心处理一个视频转码的工作
        List<MediaProcess> mediaProcessList = mediaFileProcessService.getMediaProcessList(shardTotal, shardIndex, processors);
        //当前取到的任务数量
        int size = mediaProcessList.size();
        log.debug("取到的视频处理任务数："+size);
        if(size<=0){
            return;
        }
        //创建一个线程池
        ExecutorService executorService = Executors.newFixedThreadPool(size);
        //使用计数器,确保所有线程执行完成后，任务才执行结束
        CountDownLatch countDownLatch = new CountDownLatch(size);
        mediaProcessList.forEach(
                mediaProcess -> {
                    //将任务加入线程池
                    executorService.execute(() -> {
                        try {
                            //任务执行逻辑
                            String bucket = mediaProcess.getBucket();
                            String objectName = mediaProcess.getFilePath();
                            //md5值
                            String fileId = mediaProcess.getFileId();
                            //争抢任务
                            Long taskId = mediaProcess.getId();
                            boolean b = mediaFileProcessService.startTask(taskId);
                            if (!b) {
                                log.debug("抢占任务失败，任务id:{}", taskId);
                                return;
                            }
                            //执行视频的转码
                            //下载minio视频到本地
                            File file = mediaFileService.downloadFileFromMinIO(bucket, objectName);
                            if (file == null) {
                                log.debug("下载视频出错，任务id:{},bucket:{},objectName:{}", taskId, bucket, objectName);
                                //保存任务处理失败的结果
                                mediaFileProcessService.saveProcessFinishStatus(taskId, "3", fileId, null, "下载视频到本地失败");
                                return;
                            }
                            //源avi视频的路径
                            String video_path = file.getAbsolutePath();
                            //转换后mp4文件的名称
                            String mp4_name = fileId + ".mp4";

                            //先创建一个临时文件，作为转换后的文件
                            File map4File = null;
                            try {
                                map4File = File.createTempFile("minio", ".mp4");
                            } catch (IOException e) {
                                log.debug("创建临时文件异常,{}", e.getMessage());
                                mediaFileProcessService.saveProcessFinishStatus(taskId, "3", fileId, null, "创建临时文件异常");
                                return;
                            }
                            //转换后mp4文件的路径
                            String mp4_path = map4File.getAbsolutePath();
                            //创建工具类对象
                            Mp4VideoUtil videoUtil = new Mp4VideoUtil("D:\\ffmpeg.exe", video_path, mp4_name, mp4_path);
                            //开启视频转换，成功将返回success
                            String result = videoUtil.generateMp4();
                            if (!result.equals("success")) {
                                log.debug("视频转码失败，原因:{},bucket:{},objectName:{}", result, bucket, objectName);
                                mediaFileProcessService.saveProcessFinishStatus(taskId, "3", fileId, null, result);
                                return;
                            }
                            objectName = getFilePathMd5(fileId,".mp4");
                            //上传到minio
                            boolean b1 = mediaFileService.addMediaFilesToMinIO(map4File.getAbsolutePath(), bucket, objectName, "video/mp4");
                            if (!b1){
                                log.debug("上传mp4到minio失败，taskId:{},bucket:{},objectName:{}", taskId, bucket, objectName);
                                mediaFileProcessService.saveProcessFinishStatus(taskId, "3", fileId, null, "上传mp4到minio失败");
                                return;
                            }
                            //拼装mp4文件的url
                            String filePath = getFilePathMd5(fileId, ".mp4");

                            //保存任务的状态为成功//保存任务的处理结果
                            mediaFileProcessService.saveProcessFinishStatus(taskId, "2", fileId, filePath, "任务成功");
                            file.delete();
                        } finally {
                            //计数器减1
                            countDownLatch.countDown();
                        }

                    });
                }
        );
        //阻塞等待，指定一个最大限度的等待时间，一旦出现计数器没有归0，阻塞最多等待一定时间后就解除阻塞
        countDownLatch.await(30, TimeUnit.MINUTES);

    }

    private String getFilePathMd5(String fileMd5,String extension){
        return fileMd5.substring(0,1)+"/"+fileMd5.substring(1,2)+"/"+fileMd5+"/"+fileMd5+"/"+fileMd5+extension;
    }
}
