package com.xuecheng.media;

import org.apache.commons.codec.digest.DigestUtils;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class BigFileTest {
    //分块测试
    @Test
    public void testChunk() throws IOException {
        //源文件
        File sourceFile = new File("E:\\2024最新版Java学习路线图\\第4阶段—中间键&服务框架\\2、分布式开发框架Dubbo\\资料--分布式开发框架Dubbo\\资料-Dubbo.rar");
        //分块文件存储路径
        String chunkFilePath = "E:\\develop\\upload\\chunk\\";
        //分块文件大小 1MB
        int chunkSize = 1024 * 1024 * 1;
        //分块文件个数
        int chunkNum = (int)Math.ceil(sourceFile.length()*1.0/chunkSize);
        //使用流从源文件读数据，向分块文件写数据
        RandomAccessFile r = new RandomAccessFile(sourceFile, "r");
        //缓冲区
        byte[] bytes = new byte[chunkSize];
        for (int i = 0; i < chunkNum; i++) {
            File chunkFile = new File(chunkFilePath + i);
            //创建分块文件的写入流
            RandomAccessFile w = new RandomAccessFile(chunkFile, "rw");
            int len = -1;
            //将数据读到缓冲区中
            while ((len=r.read(bytes))!=-1){
                w.write(bytes,0,len);
                if (chunkFile.length()>=chunkSize){
                    break;
                }
            }
            w.close();
        }
        r.close();
    }
    //合并分块
    @Test
    public void testFile() throws IOException {
        //源文件
        File sourceFile = new File("E:\\2024最新版Java学习路线图\\第4阶段—中间键&服务框架\\2、分布式开发框架Dubbo\\资料--分布式开发框架Dubbo\\资料-Dubbo.rar");
        //分块文件存储路径
        String chunkFilePath = "E:\\develop\\upload\\chunk\\";
        File file = new File(chunkFilePath);
        //取出分块文件下下的所有文件
        File[] files = file.listFiles();
        //将数组转成List,思路：需要对文件名进行排序，数组没有排序功能，可以将数组转为List，由Collections来排序
        List<File> fileList = Arrays.asList(files);
        Collections.sort(fileList, new Comparator<File>() {
            @Override
            public int compare(File o1, File o2) {
                return Integer.parseInt(o1.getName()) - Integer.parseInt(o2.getName());
            }
        });
        byte[] buffer = new byte[1024];
        String mergeFile = "E:\\develop\\upload\\chunk\\merge.rar";
        RandomAccessFile w = new RandomAccessFile(mergeFile, "rw");
        //遍历分块文件
        for (File file1 : fileList) {
            RandomAccessFile r = new RandomAccessFile(file1, "r");
            int len = -1;
            while ((len=r.read(buffer))!=-1){
                w.write(buffer,0,len);
            }
            r.close();
        }
        w.close();
        //合并文件完成后对合并的文件进行校验
        FileInputStream fileInputStream = new FileInputStream(mergeFile);
        FileInputStream fileInputStream2 = new FileInputStream(sourceFile);
        String md5_merge = DigestUtils.md5Hex(fileInputStream);
        String md5_source = DigestUtils.md5Hex(fileInputStream2);
        if (md5_merge.equals(md5_source)){
            System.out.println("合并文件成功");
        }
    }
}
