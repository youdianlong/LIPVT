package com.xuecheng.media;

import com.xuecheng.media.mapper.MediaProcessMapper;
import com.xuecheng.media.model.po.MediaProcess;
import com.xuecheng.media.service.MediaFileProcessService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.*;

@SpringBootTest
public class qq {
    @Autowired
    MediaFileProcessService mediaFileProcessService;

    @Test
    public void lastStoneWeight() {
        int[] stones = new int[]{2,7,4,1,8,1};
        PriorityQueue<Integer> maxHeap = new PriorityQueue<>(Collections.reverseOrder());
        for (int temp : stones) {
            maxHeap.add(temp);
        }
        int size = maxHeap.size();
        while (size != 1 && size != 0) {
            int max1 = maxHeap.poll();
            int max2 = maxHeap.poll();
            if (max1 > max2) {
                maxHeap.add(max1 - max2);
                size++;
            }
            size -= 2;
        }
        int i = maxHeap.size() == 0 ? 0 : maxHeap.poll();
        System.out.println(i);
    }
    @Test
    public void mydemo() {
        List<List<Integer>> lists = new ArrayList<>();
        List<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(3);
        list.add(2);
        lists.add(list);
        List<Integer> list1 = new ArrayList<>();
        list1.add(1);
        list1.add(3);
        list1.add(2);
        lists.add(list1);
//        Collections.sort(lists, new Comparator<List<Integer>>() {
//            @Override
//            public int compare(List<Integer> o1, List<Integer> o2) {
//                return o1.get(0) - o2.get(0);
//            }
//        });
        Collections.sort(lists, (o1, o2) -> o1.get(0) - o2.get(0));
        System.out.println(lists);
        HashMap<Integer,Integer> hashmap = new HashMap<>();
        System.out.println(-2%3);
        int[][] a = new int[1][1];
        a[0] = a[1].clone();
    }

    @Test
    public void minSumOfLengths() {
        // 在arr中找两个互不重叠的子数组且两个子数组的和都等于target，计算这两个子数组的长度和的最小值,arr[i]中的值都是正值，
        // 不用考虑sum存在多个的情况
        // 先找和为target的子数组，再在子数组中寻找区间
        int[] arr= new int[]{3,1,1,1,5,1,2,1};
        int target =3;
        HashMap<Integer, Integer> record = new HashMap<>();
        //dp[i]记录以i结尾的和为target子数组的最短长度
        int[] dp = new int[arr.length+1];
        dp[0] = Integer.MAX_VALUE/2;
        int ans = Integer.MAX_VALUE;
        int sum = 0;
        record.put(0, -1);
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
            if (record.containsKey(sum - target)) {
                // 找到何为target的子数组
                int left = record.get(sum - target);
                dp[i+1] = Math.min(i-left,dp[i]);
                //以left-1结尾的和为target的子数组长度
                if(left>=0)
                ans = Math.min(ans,dp[left+1]+i-left);
            }else{
                dp[i+1] = dp[i];
            }
            record.put(sum, i);
        }
        System.out.println(ans);
    }
    @Test
    public void testMediaProcessMapper() {

       mediaFileProcessService.getMediaProcessList(1, 0, 5);
//        System.out.println(mediaProcesses.size());
    }
}
