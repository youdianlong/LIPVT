package com.xuecheng.media;

import org.junit.jupiter.api.Test;

import javax.print.DocFlavor;
import java.util.*;

public class MyLeetcodeTest {
    class Trie{
        Trie[] children;
        int index;
        public Trie(){
            children = new Trie[26];
            index=-1;
        }
    }
    public List<List<String>> suggestedProducts(String[] products, String searchWord) {
        Trie root = new Trie();
        Map<Trie,Integer> char2Index=new HashMap<>();
        for(int k=0;k<products.length;k++){
            Trie node = root;
            for(int i=0;i<products[k].length();i++){
                //建立字典树
                int index = products[k].charAt(i)-'a';
                node = node.children[index];
                if(node.children[index]==null){
                    node = new Trie();
                }
            }
            node.index=k;
        }
        //在字典树中搜索
        List<List<String>> ans = new ArrayList<>();
        for(int i=0;i<searchWord.length();i++){
            String search = searchWord.substring(0,i+1);
            System.out.println(search);
            List<String> a = new ArrayList<>();
            Trie node = root;
            List<Integer> indexList = new ArrayList<>();
            for(int j=0;j<search.length();j++){
                if(node==null) break;
                node = node.children[search.charAt(j)-'a'];
            }
            dfs(node,indexList);
            System.out.println(indexList);
        }
        return ans;
    }
    private void dfs(Trie root,List<Integer> indexList){
        if(root==null){
            return;
        }
        if(root.index!=-1){
            indexList.add(root.index);
        }
        Trie node = root;
        for(int i=0;i<26;i++){
            node = root.children[i];
            dfs(node,indexList);
        }
    }
    @Test
    public void test(){
        String[] products =new String[]{"mobile","mouse","moneypot","monitor","mousepad"};
        suggestedProducts(products,"mouse");
        System.out.println(Arrays.toString(products));

    }
}
