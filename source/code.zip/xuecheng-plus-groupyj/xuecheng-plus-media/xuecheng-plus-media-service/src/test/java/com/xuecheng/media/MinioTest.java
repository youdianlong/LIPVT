package com.xuecheng.media;

import io.minio.MinioClient;
import io.minio.RemoveObjectArgs;
import io.minio.UploadObjectArgs;
import io.minio.errors.*;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

//测试miniotest的sdk
public class MinioTest {
    MinioClient minioClient =
            MinioClient.builder()
                    .endpoint("http://192.168.101.65:9000") //Minio地址+服务端口
                    .credentials("minioadmin", "minioadmin")//用户名+密码
                    .build();

    @Test
    public void test_upload() throws IOException, ServerException, InsufficientDataException, ErrorResponseException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        UploadObjectArgs testbucket = UploadObjectArgs.builder()
                .bucket("mediafiles")//桶
                .filename("C:\\Users\\44298\\AppData\\Local\\Temp\\minio8614027373696418559.temp")//指定本地文件路径
                .object("t2024/09/11/cc06bb3a3c14ec48384febfc4e6e32e8.jpg")//对象名
                .contentType("image/jpeg")
                .build();
        minioClient.uploadObject( testbucket);
    }
    @Test
    public void test_removeObject() throws IOException, ServerException, InsufficientDataException, ErrorResponseException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        RemoveObjectArgs testbucket = RemoveObjectArgs.builder()
                .bucket("testbucket")//桶
                .object("test.txt")//对象名
                .build();
        minioClient.removeObject(testbucket);
    }
}
