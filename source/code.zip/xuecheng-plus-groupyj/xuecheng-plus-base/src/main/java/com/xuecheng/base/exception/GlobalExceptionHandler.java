package com.xuecheng.base.exception;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.nio.file.AccessDeniedException;
import java.util.ArrayList;
import java.util.List;

@Slf4j
//全局异常处理类，ControllerAdvice表示这是增强的controller类
@ControllerAdvice
public class GlobalExceptionHandler {

   //针对用于自定义异常处理
   @ResponseBody
   @ExceptionHandler(XueChengPlusException.class)//待处理的异常
   @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)//返回给前端json信息，设置返回的状态码
   public RestErrorResponse customException(XueChengPlusException e) {
      log.error("【系统异常】{}",e.getErrMessage(),e);
      //和前端约定好的异常返回类
      return new RestErrorResponse(e.getErrMessage());

   }

   @ResponseBody
   @ExceptionHandler(Exception.class)
   @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
   public RestErrorResponse exception(Exception e) {
      if(e.getMessage().equals("不允许访问")){
         return new RestErrorResponse("您没有权限操作此功能");
      }

      log.error("【系统异常】{}",e.getMessage(),e);

      return new RestErrorResponse(CommonError.UNKOWN_ERROR.getErrMessage());

   }

   @ResponseBody
   //处理JSR303异常
   @ExceptionHandler(MethodArgumentNotValidException.class)
   @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
   public RestErrorResponse methodArgumentNotValidException(MethodArgumentNotValidException e) {
      BindingResult bindingResult = e.getBindingResult();
      List<String> msgList = new ArrayList<>();
      //将错误信息放在msgList
      bindingResult.getFieldErrors().stream().forEach(item->msgList.add(item.getDefaultMessage()));
      //拼接错误信息
      String msg = StringUtils.join(msgList, ",");
      log.error("【系统异常】{}",msg);
      return new RestErrorResponse(msg);
   }

}