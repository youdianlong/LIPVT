package com.xuecheng.base.exception;

/*
 * @Description: JSR303分组校验
 * @param null
 * @Author: yujie
 * @Date: 2024/7/3 10:50
 */
public class ValidationGroups {
 public interface Insert{};
 public interface Update{};
 public interface Delete{};
}