package com.xuecheng.ucenter.service;

import com.xuecheng.ucenter.model.po.XcUser;

/*
 * @Description: 微信认证接口
 * @param null
 * @return
 * @Author: yujie
 * @Date: 2025/3/27 14:27
 */
public interface WxAuthService {
    /*
     * @Description: 申请令牌，携带令牌查询用户信息、保存用户信息到数据库
     * @param code
     * @return com.xuecheng.ucenter.model.po.XcUser
     * @Author: yujie
     * @Date: 2025/3/27 17:01
     */
    public XcUser wxAuth(String code);
}
