package com.xuecheng.ucenter.service;

import com.xuecheng.ucenter.model.dto.AuthParamsDto;
import com.xuecheng.ucenter.model.dto.XcUserExt;

/*
 * @Description: 一个统一的认证的接口
 * @param null
 * @return
 * @Author: yujie
 * @Date: 2025/3/24 15:17
 */
public interface AuthService {
    /*
     * @Description: 认证方法，统一认证入口
     * @param authParamsDto  认证参数
     * @return com.xuecheng.ucenter.model.dto.XcUserExt 用户信息
     * @Author: yujie
     * @Date: 2025/3/24 15:18
     */
    XcUserExt execute(AuthParamsDto authParamsDto);
}
