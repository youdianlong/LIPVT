package com.xuecheng.ucenter.service.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.xuecheng.ucenter.mapper.XcMenuMapper;
import com.xuecheng.ucenter.mapper.XcUserMapper;
import com.xuecheng.ucenter.model.dto.AuthParamsDto;
import com.xuecheng.ucenter.model.dto.XcUserExt;
import com.xuecheng.ucenter.model.po.XcMenu;
import com.xuecheng.ucenter.model.po.XcUser;
import com.xuecheng.ucenter.service.AuthService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.ApplicationContext;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
public class UserServiceImpl implements UserDetailsService {

    @Autowired
    XcUserMapper xcUserMapper;
    @Autowired
    ApplicationContext applicationContext;
    @Autowired
    XcMenuMapper xcMenuMapper;

    //传入的请求认证的参数就是AuthParamsDto
    @Override
    public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {
        //将传入的json传转成AuthParamsDto对象
        AuthParamsDto authParamsDto = JSON.parseObject(s, AuthParamsDto.class);

        //获取认证类型
        String authType = authParamsDto.getAuthType();
        //策略模式：根据认证类型，从spring容器中取出指定的bean，然后执行对应的认证逻辑
        //首先拼接出beanname
        String beanName = authType+"_authservice";
        AuthService authservice = applicationContext.getBean(beanName,AuthService.class);
        //调用接口中的统一方法，完成认证
        XcUserExt xcUserExt = authservice.execute(authParamsDto);
        //封装xcUserExt用户信息为UserDetails类型，根据userDetails对象来生成令牌
        UserDetails userDetails = getUserPrincipal(xcUserExt);
        return userDetails;
    }
    private UserDetails getUserPrincipal(XcUserExt xcUserExt){
        String password = xcUserExt.getPassword();
        String[] authorities = {"test"};
        //根据用户id去查询用户的权限
        List<XcMenu> xcMenus = xcMenuMapper.selectPermissionByUserId(xcUserExt.getId());
        if(xcMenus.size()>0){
            List<String> permissions = new ArrayList<>();
            xcMenus.forEach(m->{
                //拿到用户拥有的权限标识符
                permissions.add(m.getCode());
            });
            authorities = permissions.toArray(new String[0]);
        }
        //隐藏敏感信息
        xcUserExt.setPassword(null);
        //将用户的信息转成json
        String userJson = JSON.toJSONString(xcUserExt);
        UserDetails userDetails = User.withUsername(userJson).password(password).authorities(authorities).build();
        return userDetails;
    }

}
