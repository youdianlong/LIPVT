package com.xuecheng.orders.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Configuration
public class OrderCancelConfig {
    //交换机
    public static final String DEAD_EXCHANGE = "order.dlx.exchange";
    //路由键
    public static final String ROUTING_KEY = "order.cancel.routing.key";
    //延迟队列
    public static final String DELAY_QUEUE = "order.delay.queue";
    //取消队列
    public static final String CANCEL_QUEUE = "order.cancel.queue";
    // 延迟队列
    @Bean
    public Queue orderDelayQueue() {
        Map<String, Object> args = new HashMap<>();
        args.put("x-dead-letter-exchange", DEAD_EXCHANGE);
        args.put("x-dead-letter-routing-key", ROUTING_KEY);
        args.put("x-message-ttl", 30 * 60 * 1000); // 30 分钟
        return new Queue(DELAY_QUEUE, true, false, false, args);
    }

    // 取消队列
    @Bean
    public Queue orderCancelQueue() {
        return new Queue(CANCEL_QUEUE, true);
    }

    // 死信交换机
    @Bean
    public DirectExchange orderDlxExchange() {
        return new DirectExchange(DEAD_EXCHANGE);
    }

    // 死信交换机与取消队列进行绑定
    @Bean
    public Binding bindingCancel(Queue orderCancelQueue, DirectExchange orderDlxExchange) {
        return BindingBuilder.bind(orderCancelQueue)
                .to(orderDlxExchange)
                .with(ROUTING_KEY);
    }
}
