package com.xuecheng.learning.service;

import com.xuecheng.base.model.PageResult;
import com.xuecheng.learning.model.dto.MyCourseTableParams;
import com.xuecheng.learning.model.dto.XcChooseCourseDto;
import com.xuecheng.learning.model.dto.XcCourseTablesDto;
import com.xuecheng.learning.model.po.XcCourseTables;

/*
 * @Description: 选课相关的接口
 * @param null 
 * @return
 * @Author: yujie
 * @Date: 2025/3/24 19:56
 */
public interface MyCourseTablesService {
    /**
     * @description 添加选课
     * @param userId 用户id
     * @param courseId 课程id
     * @return com.xuecheng.learning.model.dto.XcChooseCourseDto
     * @author Mr.M
     * @date 2022/10/24 17:33
     */
    public XcChooseCourseDto addChooseCourse(String userId, Long courseId);

    public XcCourseTablesDto getLearningStatus(String userId, Long courseId);

    /*
     * @Description: 保存选课记录状态
     * @param null
     * @return
     * @Author: yujie
     * @Date: 2025/3/25 16:52
     */
    boolean saveChooseCourseSuccess(String chooseCourseId);

    /**
     * @description 我的课程表
     * @param params
     * @return com.xuecheng.base.model.PageResult<com.xuecheng.learning.model.po.XcCourseTables>
     * @author Mr.M
     * @date 2022/10/27 9:24
     */
    PageResult<XcCourseTables> mycourestabls(MyCourseTableParams params);

    /*
     * @Description: 删除选课
     * @param null
     * @return
     * @Author: yujie
     * @Date: 2025/3/27 19:05
     */
    void deleteChooseCourse(String chooseCourseId);
}
