package com.xuecheng.learning.service.impl;

import com.alibaba.fastjson.JSON;
import com.rabbitmq.client.AMQP;
import com.sun.org.apache.bcel.internal.generic.NEW;
import com.xuecheng.base.exception.XueChengPlusException;
import com.xuecheng.learning.config.OrderCancelConfig;
import com.xuecheng.learning.config.PayNotifyConfig;
import com.xuecheng.learning.mapper.XcChooseCourseMapper;
import com.xuecheng.learning.service.MyCourseTablesService;
import com.xuecheng.messagesdk.model.po.MqMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/*
 * @Description: 接受消息通知
 * @param null
 * @return
 * @Author: yujie
 * @Date: 2025/3/25 16:45
 */
@Service
@Slf4j
public class ReceivePayNotifyService {

    @Autowired
    MyCourseTablesService myCourseTablesService;

    @RabbitListener(queues = PayNotifyConfig.PAYNOTIFY_QUEUE)
    public void receive(Message message){
        //这里加入延迟的作用时防止一直消息消费失败后一直重试
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        byte[] body = message.getBody();
        String jsonString = new String(body);
        //解析消息对象中的消息并将其转成对象
        MqMessage mqMessage = JSON.parseObject(jsonString, MqMessage.class);
        //解析消息的内容
        String chooseCourseId = mqMessage.getBusinessKey1();
        //订单类型
        String orderType = mqMessage.getBusinessKey2();
        //学习中心服务只要购买课程类的支付订单的结果
        if(orderType.equals("60201")){
            //根据消息里的内容，更新选课记录，向我的课程表插入记录
            boolean b = myCourseTablesService.saveChooseCourseSuccess(chooseCourseId);
            if(!b){
                XueChengPlusException.cast("保证选课记录状态失败");
            }
        }
    }

    @RabbitListener(queues = OrderCancelConfig.CANCEL_QUEUE)
    public void receiveCancel(Message message) {
        byte[] body = message.getBody();
        String jsonString = new String(body);
        //解析消息对象中的消息并将其转成对象
        MqMessage mqMessage = JSON.parseObject(jsonString, MqMessage.class);
        //解析消息的内容
        String chooseCourseId = mqMessage.getBusinessKey1();
        //从选课表中删除
        myCourseTablesService.deleteChooseCourse(chooseCourseId);
    }

}
