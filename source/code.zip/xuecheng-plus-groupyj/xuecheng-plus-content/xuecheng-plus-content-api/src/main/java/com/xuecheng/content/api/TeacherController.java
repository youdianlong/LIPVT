package com.xuecheng.content.api;

import com.xuecheng.content.model.dto.SaveTeachplanDto;
import com.xuecheng.content.model.dto.TeacherDto;
import com.xuecheng.content.model.dto.TeachplanDto;
import com.xuecheng.content.service.TeacherService;
import com.xuecheng.content.service.TeachplanService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(value = "课程计划编辑接口",tags = "课程计划编辑接口")
 @RestController
public class TeacherController {

    @Autowired
    TeacherService teacherService;

    @ApiOperation("查询教师信息")
    @GetMapping("/courseTeacher/list/{courseId}")
    public List<TeacherDto> list(@PathVariable Long courseId){
        return teacherService.list(courseId);
    }

    @ApiOperation("添加或者修改教师信息")
    @PostMapping("/courseTeacher")
    public TeacherDto addTeacher(@RequestBody TeacherDto teacherDto){
        return teacherService.addTeacher(teacherDto);
    }

//    @ApiOperation("修改教师信息")
//    @PostMapping("/courseTeacher")
//    public TeacherDto updateTeacher(@RequestBody TeacherDto teacherDto){
//        return teacherService.updateTeacher(teacherDto);
//    }

    @ApiOperation("删除教师信息")
    @DeleteMapping("/courseTeacher/course/{courseId}/{teacherId}")
    public void deleteTeacher(@PathVariable(value = "courseId") Long courseId,@PathVariable(value = "teacherId") Long teacherId){
        teacherService.deleteTeacher(courseId,teacherId);
    }
}