package com.xuecheng.content.api;

import com.xuecheng.base.model.PageParams;
import com.xuecheng.base.model.PageResult;
import com.xuecheng.content.model.dto.CourseCategoryDto;
import com.xuecheng.content.model.dto.QueryCourseParamsDto;
import com.xuecheng.content.model.po.CourseBase;
import com.xuecheng.content.service.CourseBaseInfoService;
import com.xuecheng.content.service.CourseCategoryService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/*
 * @Description: 
 * @param null 
 * @return
 * @Author: yujie
 * @Date: 2024/6/24 16:24
 */
@Api(value = "课程分类接口",tags="课程分类接口")
@RestController //Controller和RestBody的整合
public class CourseCategotyController {
    @Autowired
    private CourseCategoryService courseCategoryService;
    @ApiOperation("课程分类接口")
    @GetMapping("/course-category/tree-nodes")
    public List<CourseCategoryDto> queryCourseCategoryTreeNodes() {
        return courseCategoryService.queryTreeNodes("1");
    }
}
