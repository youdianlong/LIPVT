package com.xuecheng.content.api;

import com.alibaba.fastjson.JSON;
import com.xuecheng.content.model.dto.CourseBaseInfoDto;
import com.xuecheng.content.model.dto.CoursePreviewDto;
import com.xuecheng.content.model.dto.TeachplanDto;
import com.xuecheng.content.model.po.CoursePublish;
import com.xuecheng.content.service.CoursePublishService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class CoursePublishController {
    @Autowired
    private CoursePublishService coursePublishService;

    @GetMapping("/coursepreview/{courseId}")
    public ModelAndView preview(@PathVariable("courseId") Long courseId){
        ModelAndView mav = new ModelAndView();
        //从数据库中查询模型数据
        CoursePreviewDto coursePreview = coursePublishService.getCoursePreview(courseId);
        mav.addObject("model", coursePreview);
        //指定模型
//        mav.addObject("name","小明");
        //指定模版
        mav.setViewName("course_template");//根据视图名称加.ftl找到模版
        return mav;
    }

    @ResponseBody
    @GetMapping("/course/whole/{courseId}")
    public CoursePreviewDto getCoursePreview(@PathVariable("courseId") Long courseId){
        //查询课程发布表
        CoursePreviewDto coursePreviewDto = new CoursePreviewDto();
        CoursePublish coursepublish = coursePublishService.getCoursePublish(courseId);
        if(coursepublish == null){
            return coursePreviewDto;
        }
        CourseBaseInfoDto cbdto = new CourseBaseInfoDto();
        BeanUtils.copyProperties(coursepublish,cbdto);
        //课程计划信息
        String teachplan = coursepublish.getTeachplan();
        //将JSON格式的teachplan转为List<TeachplanDto>
        List<TeachplanDto> teachplanDtos = JSON.parseArray(teachplan, TeachplanDto.class);
        coursePreviewDto.setTeachplans(teachplanDtos);
        coursePreviewDto.setCourseBase(cbdto);
        return coursePreviewDto;

    }

    // 课程提交
    @ResponseBody
    @PostMapping("/courseaudit/commit/{courseId}")
    public void commitAudit(@PathVariable Long courseId){
        Long companyId = 1232141425L;
        coursePublishService.commitAudit(companyId,courseId);
    }

    //课程发布
    @ResponseBody
    @PostMapping("/coursepublish/{courseId}")
    public void coursePublish(@PathVariable Long courseId){
        Long companyId = 1232141425L;
        coursePublishService.publish(companyId,courseId);
    }


    @ApiOperation("获取课程发布信息")
    @ResponseBody
    @GetMapping("/r/coursepublish/{courseId}")
    public CoursePreviewDto getCoursePublish(@PathVariable("courseId") Long courseId) {
        //查询课程发布信息
        CoursePublish coursePublish = coursePublishService.getCoursePublishCache(courseId);
        if(coursePublish==null){
            return new CoursePreviewDto();
        }

        //课程基本信息
        CourseBaseInfoDto courseBase = new CourseBaseInfoDto();
        BeanUtils.copyProperties(coursePublish, courseBase);
        //课程计划
        List<TeachplanDto> teachplans = JSON.parseArray(coursePublish.getTeachplan(), TeachplanDto.class);
        CoursePreviewDto coursePreviewInfo = new CoursePreviewDto();
        coursePreviewInfo.setCourseBase(courseBase);
        coursePreviewInfo.setTeachplans(teachplans);
        return coursePreviewInfo;
    }



}
