package com.xuecheng.content.model.dto;

import com.xuecheng.content.model.po.CourseCategory;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class CourseCategoryDto extends CourseCategory implements Serializable {
    //实现serializable接口为的是在网络传输时需要序列化数据
    List<CourseCategoryDto> childrenTreeNodes;

}
