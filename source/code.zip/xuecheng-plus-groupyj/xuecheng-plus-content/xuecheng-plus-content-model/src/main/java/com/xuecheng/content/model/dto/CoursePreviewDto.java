package com.xuecheng.content.model.dto;

import lombok.Data;

import java.util.List;

/*
 * @Description: 用于课程预览的模型类
 * @param null 
 * @return
 * @Author: yujie
 * @Date: 2024/9/22 17:59
 */
@Data
public class CoursePreviewDto {
    //课程基本信息,营销信息
    private CourseBaseInfoDto courseBase;

    //课程计划信息
    private List<TeachplanDto> teachplans;
    //课程师资信息
}
