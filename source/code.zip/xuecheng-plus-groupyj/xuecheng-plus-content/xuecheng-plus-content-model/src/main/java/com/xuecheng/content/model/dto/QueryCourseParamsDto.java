package com.xuecheng.content.model.dto;

import lombok.Data;
import lombok.ToString;
/*
 * @Description: 课程查询条件模型类
 * @param null
 * @return
 * @Author: yujie
 * @Date: 2024/6/24 16:17
 */
@Data
@ToString
public class QueryCourseParamsDto {

  //审核状态
 private String auditStatus;
 //课程名称
 private String courseName;
  //发布状态
 private String publishStatus;

}