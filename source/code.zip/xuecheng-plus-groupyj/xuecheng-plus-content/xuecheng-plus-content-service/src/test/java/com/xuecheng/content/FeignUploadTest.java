package com.xuecheng.content;

import com.xuecheng.content.feignclient.MediaServiceClient;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.openfeign.EnableFeignClients;

/*
 * @Description: 测试远程调用媒资服务
 * @param null
 * @return
 * @Author: yujie
 * @Date: 2024/9/25 22:00
 */
@EnableFeignClients
@SpringBootTest
public class FeignUploadTest {
    @Autowired
    MediaServiceClient mediaServiceClient;
    @Test
    public void test(){
        //将file类型转为multipartfile类型

    }
}
