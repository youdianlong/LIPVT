package com.xuecheng;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;

/*
 * @Description: 内容管理服务启动类
 * @param null
 * @return
 * @Author: yujie
 * @Date: 2024/6/24 16:29
 */
@Configuration
@SpringBootApplication
public class ContentApplication {
    public static void main(String[] args) {
        SpringApplication.run(ContentApplication.class, args);
    }
}
