package com.xuecheng.content.service;

import com.xuecheng.base.model.PageParams;
import com.xuecheng.base.model.PageResult;
import com.xuecheng.content.model.dto.AddCourseDto;
import com.xuecheng.content.model.dto.CourseBaseInfoDto;
import com.xuecheng.content.model.dto.EditCourseDto;
import com.xuecheng.content.model.dto.QueryCourseParamsDto;
import com.xuecheng.content.model.po.CourseBase;

public interface CourseBaseInfoService {
    /*
     * @Description: 课程分页查询
     * @param pageParams 分页查询参数
     * @param queryCourseParamsDto 分页查询条件
     * @return com.xuecheng.base.model.PageResult<com.xuecheng.content.model.po.CourseBase>
     * @Author: yujie
     * @Date: 2024/6/25 11:34
     */
    public PageResult<CourseBase> queryCourseBaseList(PageParams pageParams, QueryCourseParamsDto queryCourseParamsDto);

    /*
     * @Description: 新增课程
     * @param companyId
     * @param addCourseDto
     * @return com.xuecheng.content.model.dto.CourseBaseInfoDto
     * @Author: yujie
     * @Date: 2024/6/27 12:08
     */
    public CourseBaseInfoDto createCourseBase(Long companyId, AddCourseDto addCourseDto);

    /*
     * @Description: 根据课程id查询课程信息
     * @param null
     * @return
     * @Author: yujie
     * @Date: 2024/7/5 17:45
     */
    public CourseBaseInfoDto getCourseBaseInfo(long courseId);
    /*
     * @Description: 修改课程
     * @param null
     * @return
     * @Author: yujie
     * @Date: 2024/7/5 17:59
     */
    public CourseBaseInfoDto updateCourseBase(Long companyId, EditCourseDto editCourseDto);

    /*
     * @Description: 删除课程
     * @param compantId
     * @param courseId
     * @return com.xuecheng.content.model.dto.CourseBaseInfoDto
     * @Author: yujie
     * @Date: 2024/7/7 12:31
     */
    public void deleteCourseBase(Long compantId, Long courseId);
}
