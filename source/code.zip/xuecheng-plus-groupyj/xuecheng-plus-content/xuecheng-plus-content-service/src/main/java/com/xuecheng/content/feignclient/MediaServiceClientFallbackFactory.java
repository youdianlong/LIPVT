package com.xuecheng.content.feignclient;

import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
@Component
public class MediaServiceClientFallbackFactory implements FallbackFactory<MediaServiceClient> {
    /*
     * @Description:使用fallbackfactory可以获取到异常信息
     * @param throwable
     * @return com.xuecheng.content.feignclient.MediaServiceClient
     * @Author: yujie
     * @Date: 2025/3/23 20:36
     */
    @Override
    public MediaServiceClient create(Throwable throwable) {
        return new MediaServiceClient(){
            @Override
            public String upload(MultipartFile upload, String objectName) {
                //降级方法
                log.debug("调用媒资管理服务上传文件时发生熔断，异常信息:{}",throwable.toString(),throwable);
                return null;
                //如果上游接口接受到了null，说明此时发生了降级处理
            }
        };
    }
}
