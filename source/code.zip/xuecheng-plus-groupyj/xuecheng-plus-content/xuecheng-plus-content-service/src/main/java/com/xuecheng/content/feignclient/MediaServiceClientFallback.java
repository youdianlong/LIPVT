package com.xuecheng.content.feignclient;

import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public class MediaServiceClientFallback implements MediaServiceClient {

    /*
     * @Description: 没有办法拿到发生熔断的异常，使用fallback方法，定义一个fallback类
     * @param filedata
     * @param ObjectName
     * @return java.lang.String
     * @Author: yujie
     * @Date: 2025/3/23 20:36
     */
    @Override
    public String upload(MultipartFile filedata, String ObjectName) throws IOException {
        return null;
    }
}
