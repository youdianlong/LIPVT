package com.xuecheng.content.jobhandler;

import com.xuecheng.base.exception.XueChengPlusException;
import com.xuecheng.content.feignclient.CourseIndex;
import com.xuecheng.content.feignclient.SearchServiceClient;
import com.xuecheng.content.mapper.CoursePublishMapper;
import com.xuecheng.content.model.po.CoursePublish;
import com.xuecheng.content.service.CoursePublishService;
import com.xuecheng.messagesdk.model.po.MqMessage;
import com.xuecheng.messagesdk.service.MessageProcessAbstract;
import com.xuecheng.messagesdk.service.MqMessageService;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.File;

/*
 * @Description: 执行课程任务发布的分布式事务
 * @param null
 * @return
 * @Author: yujie
 * @Date: 2025/3/23 18:39
 */
@Slf4j
@Component
public class CoursePublishTask extends MessageProcessAbstract {
    @Autowired
    CoursePublishService coursePublishService;

    @Autowired
    SearchServiceClient searchServiceClient;

    @Autowired
    CoursePublishMapper coursePublishMapper;

    //任务调度入口
    @XxlJob("CoursePublishJobHandler")
    public void coursePublishJobHandler() throws Exception {
        // 分片参数
        int shardIndex = XxlJobHelper.getShardIndex();
        int shardTotal = XxlJobHelper.getShardTotal();
        //调用抽象类执行任务
        process(shardIndex,shardTotal,"course_publish",30,60);

    }

    //执行课程发布任务的逻辑
    @Override
    public boolean execute(MqMessage mqMessage) {
        Long courseId = Long.valueOf(mqMessage.getBusinessKey1());

        //课程静态化上传到minio
        generateCourseHtml(mqMessage, courseId);

        //向es写索引数据
        saveCourseIndex(mqMessage,courseId);
        //向redis写缓存
        setCourseRedis(mqMessage,courseId);
        
        return true;
    }
    private void generateCourseHtml(MqMessage mqmessage,long courseId){
        //任务幂等性处理
        MqMessageService mqMessageService = this.getMqMessageService();
        //取出该阶段的执行状态
        int stageOne = mqMessageService.getStageOne(mqmessage.getId());
        if(stageOne > 0){
            log.debug("课程静态化任务完成，无需处理");
            return;
        }
        //开始进行课程静态化，生成html页面
        File file = coursePublishService.generateCourseHtml(courseId);
        if (file==null){
            XueChengPlusException.cast("生成的静态页面为空");
        }
        //将html页面上传到minio
        coursePublishService.uploadCourseHtml(courseId,file);
        //任务处理完成，写任务状态为完成
        mqMessageService.completedStageOne(mqmessage.getId());
    }

    private void saveCourseIndex(MqMessage mqmessage,long courseId){
        //任务幂等性处理
        MqMessageService mqMessageService = this.getMqMessageService();
        int stageTwo = mqMessageService.getStageTwo(mqmessage.getId());
        if(stageTwo > 0){
            log.debug("课程索引已建立完成，无需处理");
            return;
        }
        //开始进行在es中建立索引，利用feign完成远程调用
        //从课程发布表查询课程信息
        CoursePublish coursePublish = coursePublishMapper.selectById(courseId);
        CourseIndex courseIndex = new CourseIndex();
        BeanUtils.copyProperties(coursePublish,courseIndex);
        //远程调用
        Boolean b = searchServiceClient.add(courseIndex);
        if(!b){
            XueChengPlusException.cast("远程调用添加课程索引失败");
        }
        //任务处理完成，写任务状态为完成
        mqMessageService.completedStageTwo(mqmessage.getId());
    }
    private void setCourseRedis(MqMessage mqmessage,long courseId){
        //任务幂等性处理
        MqMessageService mqMessageService = this.getMqMessageService();
        int stageThree = mqMessageService.getStageThree(mqmessage.getId());
        if(stageThree > 0){
            log.debug("redis缓存已写入，无需处理");
            return;
        }
        //开始写入数据到redis

        //任务处理完成，写任务状态为完成
        mqMessageService.completedStageThree(mqmessage.getId());
    }
}
