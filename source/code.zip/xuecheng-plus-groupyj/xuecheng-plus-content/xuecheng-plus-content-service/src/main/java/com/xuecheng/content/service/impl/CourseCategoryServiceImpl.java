package com.xuecheng.content.service.impl;

import com.xuecheng.content.mapper.CourseCategoryMapper;
import com.xuecheng.content.model.dto.CourseCategoryDto;
import com.xuecheng.content.service.CourseCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class CourseCategoryServiceImpl implements CourseCategoryService {
    @Autowired
    private CourseCategoryMapper courseCategoryMapper;
    @Override
    public List<CourseCategoryDto> queryTreeNodes(String id) {
        List<CourseCategoryDto> courseCategoryTreeDtos = new ArrayList<>();
        //调用mapper递归查询出分类信息
        List<CourseCategoryDto> courseCategoryDtos = courseCategoryMapper.selectTreeNodes(id);
        //找到每个结点的子节点，封装成List<CourseCategoryTreeDto>
        Map<String, CourseCategoryDto> collect = courseCategoryDtos.stream().filter(item->!id.equals(item.getId())).collect(Collectors.toMap(key -> key.getId(), value -> value, (key1, key2) -> key2));
        //把根结点过滤掉
        courseCategoryDtos.stream().filter(item->!id.equals(item.getId())).forEach(item->{
            if(item.getParentid().equals(id)) {
                courseCategoryTreeDtos.add(item);
            }
            //找到每个节点的子节点放在父节点的childrenTreeNodes属性中
            CourseCategoryDto courseCategoryDtoParent = collect.get(item.getParentid());
            if(courseCategoryDtoParent != null) {
                if (courseCategoryDtoParent.getChildrenTreeNodes()==null){
                    courseCategoryDtoParent.setChildrenTreeNodes(new ArrayList<CourseCategoryDto>());
                }
                //到每个节点的子节点放在父节点的childrenTreeNodes属性中
                courseCategoryDtoParent.getChildrenTreeNodes().add(item);
            }
        });
        return courseCategoryTreeDtos;
    }
}
