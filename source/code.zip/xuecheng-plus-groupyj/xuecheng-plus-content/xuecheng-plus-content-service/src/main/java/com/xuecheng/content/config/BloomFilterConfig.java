package com.xuecheng.content.config;

import com.google.common.hash.BloomFilter;
import com.google.common.hash.Funnels;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.nio.charset.Charset;

@Configuration
public class BloomFilterConfig {

    @Bean
    public BloomFilter<String> bloomFilter() {
        // 创建一个布隆过滤器，预期插入 10000 个元素，误报率 0.01（1%）
        return BloomFilter.create(
                Funnels.stringFunnel(Charset.forName("UTF-8")), // 使用字符串 Funnel
                10000, // 预期插入元素数量
                0.01   // 期望误报率
        );
    }
}