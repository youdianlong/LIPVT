package com.xuecheng.content.service;

import com.xuecheng.content.model.dto.CoursePreviewDto;
import com.xuecheng.content.model.po.CoursePublish;

import java.io.File;

/*
 * @Description:
 * @param null
 * @return 课程发布相关接口
 * @Author: yujie
 * @Date: 2024/9/22 18:03
 */
public interface CoursePublishService {
    CoursePreviewDto getCoursePreview(Long courseId);
    void commitAudit(Long companyId,Long courseId);
    //课程发布,将预发布表的信息拷贝到发布表，并且将发布信息存储到消息表中
    void publish(Long companyId,Long courseId);

    //课程静态化，生成html页面
    File generateCourseHtml(Long courseId);

    //将html文件上传到minio
    void uploadCourseHtml(Long courseId,File file);

    public CoursePublish getCoursePublish(Long courseId);

    /*
     * @Description: 查询缓存中的课程信息
     * @param courseId
     * @return com.xuecheng.content.model.po.CoursePublish
     * @Author: yujie
     * @Date: 2025/3/27 17:25
     */
    public CoursePublish getCoursePublishCache(Long courseId);
}
