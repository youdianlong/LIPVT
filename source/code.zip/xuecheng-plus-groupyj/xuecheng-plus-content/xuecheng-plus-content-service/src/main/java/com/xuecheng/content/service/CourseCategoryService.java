package com.xuecheng.content.service;

import com.xuecheng.base.model.PageParams;
import com.xuecheng.base.model.PageResult;
import com.xuecheng.content.model.dto.CourseCategoryDto;
import com.xuecheng.content.model.dto.QueryCourseParamsDto;
import com.xuecheng.content.model.po.CourseBase;

import java.util.List;

public interface CourseCategoryService {
    /*
     * @Description:根据id查询分类信息
     * @param pageParams
     * @param queryCourseParamsDto
     * @return com.xuecheng.base.model.PageResult<com.xuecheng.content.model.po.CourseBase>
     * @Author: yujie
     * @Date: 2024/6/25 16:45
     */
    public List<CourseCategoryDto> queryTreeNodes(String id);

}
