
package com.xuecheng.content.service;

import com.xuecheng.content.model.dto.SaveTeachplanDto;
import com.xuecheng.content.model.dto.TeacherDto;
import com.xuecheng.content.model.dto.TeachplanDto;

import java.util.List;

public interface TeacherService {

 public List<TeacherDto> list(Long courseId);

 public TeacherDto addTeacher(TeacherDto teacherDto);

 public TeacherDto updateTeacher(TeacherDto teacherDto);

 public void deleteTeacher(Long courseId, Long teacherId);
}