
package com.xuecheng.content.service;

import com.xuecheng.content.model.dto.BindTeachplanMediaDto;
import com.xuecheng.content.model.dto.SaveTeachplanDto;
import com.xuecheng.content.model.dto.TeachplanDto;

import java.util.List;

public interface TeachplanService {

/*
 * @Description: 查询课程计划树型结构
 * @param courseId
 * @return java.util.List<com.xuecheng.content.model.dto.TeachplanDto>
 * @Author: yujie
 * @Date: 2024/7/6 17:47
 */
 public List<TeachplanDto> findTeachplanTree(long courseId);

 public void saveTeachplan(SaveTeachplanDto teachplanDto);

 public void deleteTeachplan(Long id);

 public void upTeachplan(Long courseId);

 public void downTeachplan(Long courseId);

 public void associationMedia(BindTeachplanMediaDto bindTeachplanMediaDto);
}