package com.xuecheng.content.service;

import com.xuecheng.content.model.po.CoursePublish;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 课程发布 服务类
 * </p>
 *
 * @author itcast
 * @since 2024-06-24
 */
public interface CoursePublishService extends IService<CoursePublish> {

}
