package com.yu.example.common.service;

import com.yu.example.common.model.User;

public interface UserService {
    User getUser(User user);
}
