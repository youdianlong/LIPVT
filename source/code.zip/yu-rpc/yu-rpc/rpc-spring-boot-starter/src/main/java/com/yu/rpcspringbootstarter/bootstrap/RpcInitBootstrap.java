package com.yu.rpcspringbootstarter.bootstrap;

import com.yu.rpc.RpcApplication;
import com.yu.rpc.config.RpcConfig;
import com.yu.rpc.transport.server.NettyServer;
import com.yu.rpcspringbootstarter.annotation.EnablePrc;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
import org.springframework.core.type.AnnotationMetadata;

/**
 * 框架启动
 */
public class RpcInitBootstrap implements ImportBeanDefinitionRegistrar {

    /**
     * Spring 初始化时执行，初始化框架，
     * ImportBeanDefinitionRegistrar ：Spring 提供的一个接口，允许开发者在容器启动时动态注册 bean 定义。
     * registerBeanDefinitions：该方法在 Spring 容器解析配置类时被调用，用于注册 bean 定义或执行自定义初始化逻辑。
     */
    @Override
    public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
        boolean needServer = (boolean) importingClassMetadata.getAnnotationAttributes(EnablePrc.class.getName()).get("needServer");
        RpcApplication.init();

        final RpcConfig rpcConfig = RpcApplication.getRpcConfig();

        if (needServer) {
            new Thread(() -> new NettyServer().doStart(Integer.parseInt(rpcConfig.getPort()))).start();
        }
    }
}
