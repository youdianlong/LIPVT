package com.yu.rpcspringbootstarter.bootstrap;

import com.yu.rpcspringbootstarter.annotation.RpcReference;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import com.yu.rpc.proxy.ServiceProxyFactory;

import java.lang.reflect.Field;

public class RpcConsumerBootstrap implements BeanPostProcessor {
    //在 Spring 容器初始化 bean 后对其进行后处理
    //扫描 bean 中的字段，查找带有 @RpcReference 注解的字段，并为这些字段注入 RPC 代理对象，从而支持远程服务调用。
    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        Class<?> beanClass = bean.getClass();
        //得到该bean的所有字段
        Field[] declaredFields = beanClass.getDeclaredFields();
        //检查每个字段，判断其是否需要被代理
        for (Field field : declaredFields) {
            RpcReference rpcReference = field.getAnnotation(RpcReference.class);
            if (rpcReference != null) {
                //  为属性生成代理对象
                Class<?> interfaceClass = rpcReference.interfaceClass();
                if (interfaceClass == void.class) {
                    interfaceClass = field.getType();
                }

                field.setAccessible(true);
                Object proxy = ServiceProxyFactory.getProxy(interfaceClass);
                try {
                    //将代理对象注入到bean对应的字段中
                    field.set(bean, proxy);
                    //恢复字段的访问权限
                    field.setAccessible(false);
                } catch (Exception e) {
                    throw new RuntimeException("为字段注入代理对象失败", e);
                }
            }
        }

        //调用父类默认实现，返回处理后的 bean。
        return BeanPostProcessor.super.postProcessAfterInitialization(bean, beanName);
    }
}
