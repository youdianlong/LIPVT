package com.yu.rpcspringbootstarter.annotation;

import com.yu.rpcspringbootstarter.bootstrap.RpcConsumerBootstrap;
import com.yu.rpcspringbootstarter.bootstrap.RpcInitBootstrap;
import com.yu.rpcspringbootstarter.bootstrap.RpcProviderBootstrap;
import org.springframework.context.annotation.Import;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 启用 RPC
 */
@Target({ElementType.TYPE})  //指定注解 @EnablePrc 只能用于类、接口或枚举
@Retention(RetentionPolicy.RUNTIME) //定义注解的保留策略为 RUNTIME，即注解在运行时仍然可用。
//Spring提供元注解，用于导入指定的配置类或组件，当一个类标注 @EnablePrc 时，
//Spring 会自动将 RpcInitBootstrap、RpcProviderBootstrap 和 RpcConsumerBootstrap 这三个类注入到 Spring 容器中。
@Import({RpcInitBootstrap.class, RpcProviderBootstrap.class, RpcConsumerBootstrap.class})
public @interface EnablePrc {

    boolean needServer() default true;
}