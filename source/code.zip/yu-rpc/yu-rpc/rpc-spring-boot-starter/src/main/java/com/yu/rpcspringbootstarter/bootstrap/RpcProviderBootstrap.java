package com.yu.rpcspringbootstarter.bootstrap;

import com.yu.rpc.RpcApplication;
import com.yu.rpc.config.RegistryConfig;
import com.yu.rpc.config.RpcConfig;
import com.yu.rpc.model.ServiceMetaInfo;
import com.yu.rpc.registry.LocalRegistry;
import com.yu.rpc.registry.Registry;
import com.yu.rpc.registry.RegistryFactory;
import com.yu.rpcspringbootstarter.annotation.RpcService;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

/**
 * 服务提供者启动
 * 获取所有包含 @RpcService 注解的类，利用 Spring 的特性监听 Bean 的加载
 */
public class RpcProviderBootstrap implements BeanPostProcessor {

    //在 Spring 容器初始化 bean 后对其进行后处理
    //找到所有加了@RpcService 注解的类
    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        Class<?> beanClass = bean.getClass();
        RpcService rpcService = beanClass.getAnnotation(RpcService.class);
        if (rpcService != null) {
            //  注册服务
            //  1.获取服务基本信息
            Class<?> interfaceClass = rpcService.interfaceClass();
            if (interfaceClass == void.class) {
                interfaceClass = beanClass.getInterfaces()[0];
            }
            //获取接口名，服务名
            String serviceName = interfaceClass.getName();
            String serviceVersion = rpcService.serviceVersion();
            //  2.注册服务
            //  本地注册实现类服务，beanClass为实现类名
            LocalRegistry.register(serviceName, beanClass);

            final RpcConfig rpcConfig = RpcApplication.getRpcConfig();
            // 注册服务到注册中心
            RegistryConfig registryConfig = rpcConfig.getRegistryConfig();
            Registry registry = RegistryFactory.getInstance(registryConfig.getRegistry());

            ServiceMetaInfo metaInfo = ServiceMetaInfo.builder()
                    .serviceName(serviceName)
                    .host(rpcConfig.getHost())
                    .port(rpcConfig.getPort())
                    .build();
            //将服务提供者的结点信息注册到etcd中
            registry.register(metaInfo);
        }
        return BeanPostProcessor.super.postProcessAfterInitialization(bean, beanName);
    }

}
