package com.yu.example.consumer;

import com.yu.example.common.model.User;
import com.yu.example.common.service.UserService;
import com.yu.rpc.proxy.ServiceProxyFactory;

import java.util.Scanner;

/*
 * @Description: 简易服务消费者
 * @param null
 * @return
 * @Author: yujie
 * @Date: 2025/3/12 20:25
 */
public class EasyConsumerExample {
    public static void main(String[] args) throws InterruptedException {
        UserService userService = ServiceProxyFactory.getProxy(UserService.class);
        User user = new User();
        user.setName("yujie");
        //调用远程服务
//        User newuser = userService.getUser(user);
//        if(newuser != null){
//            System.out.println(newuser.getName());
//        }else{
//            System.out.println("user == null");
//        }
        System.out.println(userService.getUser(user));
    }
}
