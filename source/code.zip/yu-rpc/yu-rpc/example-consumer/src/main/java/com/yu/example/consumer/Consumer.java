package com.yu.example.consumer;

import com.yu.example.common.model.User;
import com.yu.example.common.service.UserService;
import com.yu.rpc.bootstrap.ConsumerBootstrap;
import com.yu.rpc.proxy.ServiceProxyFactory;

public class Consumer {
    public static void main(String[] args) {
        // 服务提供者初始化
        ConsumerBootstrap.init();
        UserService userService = ServiceProxyFactory.getProxy(UserService.class);
        User user = new User();
        for (int i = 0; i < 10; i++) {
            user.setName("yujie"+i);
            //调用远程服务
            System.out.println(userService.getUser(user));
        }
    }
}
