package com.yu.rpc;


import com.yu.rpc.config.RegistryConfig;
import com.yu.rpc.config.RpcConfig;
import com.yu.rpc.constant.RpcConstant;
import com.yu.rpc.registry.Registry;
import com.yu.rpc.registry.RegistryFactory;
import com.yu.rpc.utils.ConfigUtils;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RpcApplication {

    private static volatile RpcConfig rpcConfig;

    public static void init() {
        RpcConfig custom;
        try {
            custom = ConfigUtils.loadConfig(RpcConfig.class, RpcConstant.DEFAULT_CONFIG_PREFIX);
        } catch (Exception e) {
            custom = new RpcConfig();
        }
        init(custom);
    }

    public static void init(RpcConfig customConfig) {
        //根据RPC框架的配置信息完成初始化
        rpcConfig = customConfig;
        log.info("yu-rpc init, config = {}", customConfig.toString());
        //获取服务注册和发现的配置信息
        RegistryConfig registryConfig = rpcConfig.getRegistryConfig();
        //初始化etcd
        Registry registry = RegistryFactory.getInstance(registryConfig.getRegistry());
        registry.init(registryConfig);
        log.info("{} registry init, config = {}", registryConfig.getRegistry(), registryConfig);
        // 创建并注册 Shutdown Hook，JVM 退出时执行操作
        Runtime.getRuntime().addShutdownHook(new Thread(registry::destory, "jvm-manager"));
    }

    public static RpcConfig getRpcConfig() {
        if (rpcConfig == null) {
            synchronized (RpcApplication.class) {
                if (rpcConfig == null) {
                    init();
                }
            }
        }
        return rpcConfig;
    }
}