package com.yu.rpc.bootstrap;

import com.yu.rpc.RpcApplication;

/*
 * @Description: 服务消费者启动类
 * @param null
 * @return
 * @Author: yujie
 * @Date: 2025/3/16 17:30
 */
public class ConsumerBootstrap {
    public static void init(){
        RpcApplication.init();
    }
}
