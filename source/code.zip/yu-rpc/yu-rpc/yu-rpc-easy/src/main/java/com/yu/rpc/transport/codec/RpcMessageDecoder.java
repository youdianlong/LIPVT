package com.yu.rpc.transport.codec;

import com.yu.rpc.enums.MessageSerializer;
import com.yu.rpc.enums.MessageType;
import com.yu.rpc.model.RpcRequest;
import com.yu.rpc.model.RpcResponse;
import com.yu.rpc.protocol.ProtocolConstant;
import com.yu.rpc.protocol.ProtocolMessage;
import com.yu.rpc.serializer.Serializer;
import com.yu.rpc.serializer.SerializerFactory;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.LengthFieldBasedFrameDecoder;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RpcMessageDecoder extends LengthFieldBasedFrameDecoder {
    //它利用了 Netty 的 LengthFieldBasedFrameDecoder，这是一个专门设计来解决粘包和拆包问题的解码器

    public RpcMessageDecoder() {
        this(ProtocolConstant.MAX_FRAME_LENGTH, 13, 4, 0, 0);
        //maxFrameLength = ProtocolConstant.MAX_FRAME_LENGTH: 最大帧长度，防止缓冲区溢出。
        //lengthFieldOffset = 13: 消息长度字段的偏移量（从第 13 字节开始）。
        //lengthFieldLength = 4: 长度字段占 4 字节（int 类型）。
        //lengthAdjustment = 0: 长度调整值，通常为 0。
        //initialBytesToStrip = 0: 不跳过初始字节。
    }

    public RpcMessageDecoder(int maxFrameLength, int lengthFieldOffset, int lengthFieldLength,
                             int lengthAdjustment, int initialBytesToStrip) {
        super(maxFrameLength, lengthFieldOffset, lengthFieldLength, lengthAdjustment, initialBytesToStrip);
    }

    @Override
    protected Object decode(ChannelHandlerContext ctx, ByteBuf in) throws Exception {
        //利用 LengthFieldBasedFrameDecoder 从字节流中提取完整帧，返回 ByteBuf。
        Object decode = super.decode(ctx, in);
        if (decode instanceof ByteBuf byteBuf) {
            try {
                byte magic = byteBuf.readByte();
                if (magic != ProtocolConstant.PROTOCOL_MAGIC) {
                    throw new IllegalArgumentException("Unknown magic code: " + magic);
                }
                byte version = byteBuf.readByte();
                byte codec = byteBuf.readByte();
                byte type = byteBuf.readByte();

                ProtocolMessage.Header header = new ProtocolMessage.Header();
                header.setMagic(magic);
                header.setVersion(version);
                header.setCodec(codec);
                header.setType(type);
                header.setStatus(byteBuf.readByte());
                header.setRequestId(byteBuf.readLong());
                int bodyLength = byteBuf.readInt();
                byte[] body = new byte[bodyLength];
                byteBuf.readBytes(body);

                //根据协议中的codec获取对应的反序列化器
                MessageSerializer serializerEnum = MessageSerializer.getEnumByKey(codec);
                Serializer serializer = SerializerFactory.getInstance(serializerEnum.getVal());

                ProtocolMessage<Object> protocolMessage = new ProtocolMessage<>();
                protocolMessage.setHeader(header);

                if (type == MessageType.REQUEST.getKey()) {
                    RpcRequest rpcRequest = serializer.deserialize(body, RpcRequest.class);
                    protocolMessage.setBody(rpcRequest);
                }
                if (type == MessageType.RESPONSE.getKey()) {
                    RpcResponse rpcResponse = serializer.deserialize(body, RpcResponse.class);
                    protocolMessage.setBody(rpcResponse);
                }

                return protocolMessage;
            } catch (Exception e) {
                log.error("Decode error.", e);
            } finally {
                byteBuf.release();
            }
        }
        return decode;
    }
}
