package com.yu.rpc.factory;

import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class SingletonFactory {

    //将单例存储到ConcurrentHashMap中，实现单例工厂
    private static final Map<String, Object> OBJECT_MAP = new ConcurrentHashMap<>();

    private static final Object lock = new Object();

    private SingletonFactory() {
    }

    public static <T> T getInstance(Class<T> clazz) {
        if (clazz == null) {
            throw new IllegalArgumentException();
        }
        String key = clazz.toString();
        if (OBJECT_MAP.containsKey(key)) {
            //如果已经创建过单例类了，直接返回存储集合中的数据
            return clazz.cast(OBJECT_MAP.get(key));
        } else {
            //如果过去没有创建过，则开锁进行创建
            synchronized (lock) {
                //如果此时已经加锁，同一时间只有一个线程进入
                if (!OBJECT_MAP.containsKey(key)) {
                    //再次检查，双重检索模式
                    try {
                        T instance = clazz.getDeclaredConstructor().newInstance();
                        OBJECT_MAP.put(key, instance);
                        return instance;
                    } catch (InvocationTargetException | InstantiationException | IllegalAccessException |
                             NoSuchMethodException e) {
                        throw new RuntimeException(e);
                    }
                } else {
                    return clazz.cast(OBJECT_MAP.get(key));
                }
            }
        }
    }

}
