package com.yu.rpc.transport.client;

import com.yu.rpc.enums.MessageStatus;
import com.yu.rpc.model.RpcResponse;
import com.yu.rpc.protocol.ProtocolMessage;

import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

public class UnprocessedRequests {
    //异步任务的响应结果类型：ProtocolMessage<RpcResponse>>
    private static final Map<Long, CompletableFuture<ProtocolMessage<RpcResponse>>> UNPROCESSED_RESPONSE_FUTURES = new ConcurrentHashMap<>();

    public void put(Long reqId, CompletableFuture<ProtocolMessage<RpcResponse>> future) {
        UNPROCESSED_RESPONSE_FUTURES.put(reqId, future);
    }

    public void complete(ProtocolMessage<RpcResponse> result) {
        //将未处理的消息从记录中移出
        CompletableFuture<ProtocolMessage<RpcResponse>> future = UNPROCESSED_RESPONSE_FUTURES.remove(result.getHeader().getRequestId());
        Integer respStatus = result.getBody().getStatus();
        if (future != null) {
            //判断响应的消息是否调用成功
            if (respStatus == MessageStatus.OK.getVal())
                //CompletableFuture 类中的 complete() 方法用于手动完成一个异步任务，并设置其结果。
                // 通过调用 complete() 方法，可以将一个特定的结果设置到 CompletableFuture 对象中，
                // 然后任何等待该异步任务的操作都会得到这个预先设置的结果。
                future.complete(result);
            else {
                future.completeExceptionally(new RuntimeException(result.getBody().getException()));
            }
        } else {
            throw new IllegalStateException();
        }
    }
}
