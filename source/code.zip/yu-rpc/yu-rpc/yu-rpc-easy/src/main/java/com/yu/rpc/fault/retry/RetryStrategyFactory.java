package com.yu.rpc.fault.retry;

import com.yu.rpc.spi.SpiLoader;

/*
 * @Description: 重试策略工厂，用于获取重试器
 * @param null
 * @return
 * @Author: yujie
 * @Date: 2025/3/16 18:13
 */
public class RetryStrategyFactory {
    static {
        SpiLoader.load(RetryStrategy.class);
    }
    public static final RetryStrategy DEFAULT_RETRY_STRATEGY = new NoRetryStrategy();
    public static RetryStrategy getInstance(String key) {
        return SpiLoader.getInstance(RetryStrategy.class, key);
    }
}
