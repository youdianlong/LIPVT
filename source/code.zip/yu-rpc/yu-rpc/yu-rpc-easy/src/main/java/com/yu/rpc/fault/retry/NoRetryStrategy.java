package com.yu.rpc.fault.retry;

import com.yu.rpc.model.RpcResponse;

import java.util.concurrent.Callable;

/*
 * @Description: 不重试策略
 * @param null
 * @return
 * @Author: yujie
 * @Date: 2025/3/16 18:11
 */
public class NoRetryStrategy implements RetryStrategy{
    @Override
    public RpcResponse retry(Callable<RpcResponse> callable) throws Exception {
        return callable.call();
    }
}
