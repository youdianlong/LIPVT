package com.yu.rpc.registry;



import cn.hutool.core.collection.CollUtil;
import cn.hutool.cron.CronUtil;
import cn.hutool.cron.task.Task;
import cn.hutool.json.JSONUtil;
import com.yu.rpc.config.RegistryConfig;
import com.yu.rpc.factory.SingletonFactory;
import com.yu.rpc.model.ServiceMetaInfo;
import io.etcd.jetcd.*;
import io.etcd.jetcd.options.GetOption;
import io.etcd.jetcd.options.PutOption;
import io.etcd.jetcd.watch.WatchEvent;
import lombok.extern.slf4j.Slf4j;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Slf4j
public class EtcdRegistry implements Registry {

    private static Client client;

    private static KV kvClient;

    private static final String ETCD_ROOT_PATH = "/rpc/";

    private static final Set<String> localRegisterNodeKeySet = new HashSet<>();

    private static final Set<String> watchingServiceNodeSet = new HashSet<>();

    private static final ScheduledExecutorService scheduledExecutorService = Executors.newScheduledThreadPool(1);

//    private final CaffeineServiceCache cache = new CaffeineServiceCache();
    private final CaffeineServiceCache cache = SingletonFactory.getInstance(CaffeineServiceCache.class);

    @Override
    public void init(RegistryConfig registryConfig) {
        Long timeout = registryConfig.getTimeout();
        client = Client.builder()
                .endpoints(registryConfig.getAddress())
                .connectTimeout(Duration.ofMillis(timeout))
                .build();
        kvClient = client.getKVClient();
//        scheduledExecutorService.scheduleAtFixedRate(this::heartBeat, 0L, 5L, TimeUnit.SECONDS);
        heartBeat();
    }

    @Override
    public void register(ServiceMetaInfo serviceMetaInfo) {
        Lease lease  = client.getLeaseClient();


        try {
            // 创建一个 30 秒的租约
            long leaseId = lease.grant(30).get().getID();
            String registerKey = ETCD_ROOT_PATH + serviceMetaInfo.getServiceNodeKey();

            ByteSequence key = ByteSequence.from(registerKey, StandardCharsets.UTF_8);
            ByteSequence value = ByteSequence.from(JSONUtil.toJsonStr(serviceMetaInfo), StandardCharsets.UTF_8);
            log.info("register key:{}", registerKey);
            log.info("register value:{}", value);
            PutOption option = PutOption.builder().withLeaseId(leaseId).build();
            kvClient.put(key, value, option).get();
            localRegisterNodeKeySet.add(registerKey);
        } catch (Exception e) {
            log.error("server register failed: {}", e.getMessage(), e);
        }
    }

    @Override
    public void logout(ServiceMetaInfo serviceMetaInfo) {
        String registryKey = ETCD_ROOT_PATH + serviceMetaInfo.getServiceNodeKey();
        kvClient.delete(ByteSequence.from(registryKey, StandardCharsets.UTF_8));
        localRegisterNodeKeySet.remove(registryKey);
    }

    @Override
    public List<ServiceMetaInfo> serviceDiscovery(String serviceKey) {

        List<ServiceMetaInfo> serviceMetaInfos = cache.read(serviceKey);
        if (CollUtil.isNotEmpty(serviceMetaInfos)) {
            return serviceMetaInfos;
        }

        String prefix = ETCD_ROOT_PATH + serviceKey + "/";

        try {
            GetOption option = GetOption.builder()
                    .isPrefix(true)
                    .build();
            List<KeyValue> kvs = kvClient.get(ByteSequence.from(prefix, StandardCharsets.UTF_8), option).get().getKvs();
            List<ServiceMetaInfo> metaInfos = kvs.stream().map(kv -> {
                watch(kv.getKey().toString(StandardCharsets.UTF_8));
                String str = kv.getValue().toString(StandardCharsets.UTF_8);
                return JSONUtil.toBean(str, ServiceMetaInfo.class);
            }).toList();
            cache.write(serviceKey, metaInfos);
            return metaInfos;
        } catch (Exception e) {
            log.error("server discovery [{}] failed: {}", serviceKey, e.getMessage(), e);
        }
        return null;
    }

    @Override
    public void destory() {
        log.info("current node offline");
        for (String key : localRegisterNodeKeySet) {
            try {
                kvClient.delete(ByteSequence.from(key, StandardCharsets.UTF_8)).get();
            } catch (Exception e) {
                log.error("{} failed to offline", key, e);
            }
        }
        if (Objects.nonNull(kvClient)) kvClient.close();
        if (Objects.nonNull(client)) client.close();
        scheduledExecutorService.shutdown();
    }

//    @Override
//    public void heartBeat() {
//        for (String key : localRegisterNodeKeySet) {
//            try {
//                List<KeyValue> kvs = kvClient.get(ByteSequence.from(key, StandardCharsets.UTF_8)).get().getKvs();
//                if (CollUtil.isEmpty(kvs)) {
//                    continue;
//                }
//                KeyValue keyValue = kvs.get(0);
//                String value = keyValue.getValue().toString(StandardCharsets.UTF_8);
//                ServiceMetaInfo bean = JSONUtil.toBean(value, ServiceMetaInfo.class);
//                register(bean);
//            } catch (Exception e) {
//                log.error("failed to renew: {}", key, e);
//            }
//        }
//    }

    public void heartBeat(){
        // 10 秒续签一次
        CronUtil.schedule("*/10 * * * * *", new Task() {
            @Override
            public void execute() {
                // 遍历本节点所有的 key
                for (String key : localRegisterNodeKeySet) {
                    try {
                        List<KeyValue> keyValues = kvClient.get(ByteSequence.from(key, StandardCharsets.UTF_8))
                                .get()
                                .getKvs();
                        // 该节点已过期（需要重启节点才能重新注册）
                        if (CollUtil.isEmpty(keyValues)) {
                            continue;
                        }
                        // 节点未过期，重新注册（相当于续签）
                        KeyValue keyValue = keyValues.get(0);
                        String value = keyValue.getValue().toString(StandardCharsets.UTF_8);
                        ServiceMetaInfo serviceMetaInfo = JSONUtil.toBean(value, ServiceMetaInfo.class);
                        register(serviceMetaInfo);
                    } catch (Exception e) {
                        throw new RuntimeException(key + "续签失败", e);
                    }
                }
            }
        });

        // 支持秒级别定时任务
        CronUtil.setMatchSecond(true);
        CronUtil.start();
    }

    @Override
    public void watch(String serviceNodeKey) {
        Watch watchClient = client.getWatchClient();
        boolean isNew = watchingServiceNodeSet.add(serviceNodeKey);
        if (isNew) {
            watchClient.watch(ByteSequence.from(serviceNodeKey, StandardCharsets.UTF_8), o -> {
                for (WatchEvent event : o.getEvents()) {
                    if (event.getEventType().equals(WatchEvent.EventType.DELETE)) {
                        cache.remove(serviceNodeKey);
                    }
                }
            });
        }
    }
}