package com.yu.rpc.fault.retry;

import com.yu.rpc.model.RpcResponse;

import java.util.concurrent.Callable;

public interface RetryStrategy {
    //重试策略
    RpcResponse retry(Callable<RpcResponse> callable) throws Exception;
}
