package com.yu.rpc.registry;

import com.yu.rpc.config.RegistryConfig;
import com.yu.rpc.model.ServiceMetaInfo;

import java.util.List;

//实现服务的发布与注册，做成接口，方便后续有多种不同的实现
public interface Registry {
    void init(RegistryConfig registryConfig);

    /**
     * 注册服务（服务端）
     */
    void register(ServiceMetaInfo serviceMetaInfo);

    /**
     * 注销服务（服务端）
     */
    void logout(ServiceMetaInfo serviceMetaInfo);

    /**
     * 发现服务（获取某服务的所有节点，消费端）
     */
    List<ServiceMetaInfo> serviceDiscovery(String serviceKey);

    /**
     * 服务销毁
     */
    void destory();

    /**
     * 心跳检测（服务端）
     */
    void heartBeat();

    /**
     * 监听（消费端）
     */
    void watch(String serviceNodeKey);
}
