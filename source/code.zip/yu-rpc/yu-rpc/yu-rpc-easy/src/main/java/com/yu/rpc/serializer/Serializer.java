package com.yu.rpc.serializer;

import java.io.IOException;

/*
 * @Description: 序列化接口
 * @param null
 * @return
 * @Author: yujie
 * @Date: 2025/3/12 21:22
 */
public interface Serializer {
    //在编写处理请求的逻辑前，我们要先实现序列化器模块。因为无论是请求或响应，都会涉及参数的传输。而 Java 对象是存活在 JVM 虚拟机中的，如果想在其他位置存储并访问、或者在网络中进行传输，就需要进行序列化和反序列化。
    //序列化：将 Java 对象转为可传输的字节数组。
    //反序列化：将字节数组转换为 Java 对象。
    //有很多种不同的序列化方式，比如 Java 原生序列化、JSON、Hessian、Kryo、protobuf 等。
    //在 RPC 模块中编写序列化接口 Serializer，提供序列化和反序列化两个方法，便于后续扩展更多的序列化器。

    //序列化
    <T> byte[] serialize(T obj) throws IOException;

    //反序列化
    <T> T deserialize(byte[] data, Class<T> clazz) throws IOException;
}
