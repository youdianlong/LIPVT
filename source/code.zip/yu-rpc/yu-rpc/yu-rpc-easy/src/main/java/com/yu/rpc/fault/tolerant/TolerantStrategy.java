package com.yu.rpc.fault.tolerant;

import com.yu.rpc.model.RpcResponse;

import java.util.Map;

/*
 * @Description: 服务容错策略
 * @param null
 * @return
 * @Author: yujie
 * @Date: 2025/3/16 18:52
 */
public interface TolerantStrategy {
    RpcResponse doTolerant(Map<String, Object> context, Exception e);
}
