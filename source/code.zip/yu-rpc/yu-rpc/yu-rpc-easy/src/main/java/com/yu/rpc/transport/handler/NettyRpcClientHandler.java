package com.yu.rpc.transport.handler;

import com.yu.rpc.enums.MessageType;
import com.yu.rpc.factory.SingletonFactory;
import com.yu.rpc.model.RpcResponse;
import com.yu.rpc.protocol.ProtocolMessage;
import com.yu.rpc.transport.client.UnprocessedRequests;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.util.ReferenceCountUtil;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class NettyRpcClientHandler extends ChannelInboundHandlerAdapter {

    //收到消息来自服务器的消息后，进行处理，唤醒之前被阻塞的线程
    private final UnprocessedRequests unprocessedRequests;

    public NettyRpcClientHandler() {
        unprocessedRequests = SingletonFactory.getInstance(UnprocessedRequests.class);
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) {
        try {
            log.info("client receive msg: [{}]", msg);
            if (msg instanceof ProtocolMessage<?> response) {
                ProtocolMessage.Header header = response.getHeader();
                byte type = header.getType();
                //收到响应消息
                if (type == MessageType.RESPONSE.getKey()) {
                    unprocessedRequests.complete((ProtocolMessage<RpcResponse>) response);
                }
            }
        } finally {
            ReferenceCountUtil.release(msg);
        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        log.error("client caught exception.", cause);
        cause.printStackTrace();
        ctx.close();
    }
}
