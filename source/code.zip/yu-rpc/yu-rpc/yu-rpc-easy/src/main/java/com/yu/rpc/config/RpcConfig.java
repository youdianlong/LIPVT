package com.yu.rpc.config;

import com.yu.rpc.constant.LoadBalancerConstant;
import lombok.Data;

@Data
public class RpcConfig {

    private String name = "yu-rpc";

    private String version = "1.0";

    private Boolean mock = false;

    private String host;

    private String port="9394";

    private String serializer = "jdk";

    private RegistryConfig registryConfig = new RegistryConfig();

    private String loadBalancer = LoadBalancerConstant.RANDOM;

    private String retryStrategy = "no";
}
