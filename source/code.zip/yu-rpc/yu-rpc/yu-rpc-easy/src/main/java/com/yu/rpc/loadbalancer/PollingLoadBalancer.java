package com.yu.rpc.loadbalancer;

import com.yu.rpc.model.ServiceMetaInfo;

import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class PollingLoadBalancer implements LoadBalancer {

    //使用 AtomicInteger count 作为一个计数器，每次调用 select 方法时通过 getAndIncrement() 获取当前值并自增。
    //通过 count.getAndIncrement() % size 计算出目标服务器的索引，确保索引在 serviceMetaInfos 列表的大小范围内循环。
//    使用 AtomicInteger 确保在多线程环境下计数器的增量操作是线程安全的
    private static final AtomicInteger count = new AtomicInteger();

    @Override
    public ServiceMetaInfo select(Map<String, Object> params, List<ServiceMetaInfo> serviceMetaInfos) {
        if (serviceMetaInfos.isEmpty()) {
            return null;
        }
        int size = serviceMetaInfos.size();
        if (size == 1) {
            return serviceMetaInfos.get(0);
        }
        return serviceMetaInfos.get(count.getAndIncrement() % size);
    }
}
