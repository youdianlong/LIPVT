package com.yu.rpc.config;

import lombok.Data;

//服务发现与注册配置
@Data
public class RegistryConfig {
    private String registry = "etcd";

    private String address = "http://192.168.101.65:2379";

    private String username;

    private String password;

    private Long timeout = 10000L;

//    private String registry = "zookeeper";
//
//    private String address = "192.168.101.65:2181";
//
//    private String username;
//
//    private String password;
//
//    private Long timeout = 10000L;
}
