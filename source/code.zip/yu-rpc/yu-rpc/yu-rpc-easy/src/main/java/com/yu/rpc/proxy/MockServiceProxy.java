package com.yu.rpc.proxy;

// 导入 Lombok 的 Slf4j 注解，用于简化日志记录
import lombok.extern.slf4j.Slf4j;

// 导入 Java 反射包中的 InvocationHandler 接口，用于动态代理
import java.lang.reflect.InvocationHandler;

// 导入 Java 反射包中的 Method 类，用于操作方法反射
import java.lang.reflect.Method;

// 使用 Slf4j 注解，为类自动生成日志对象 log
@Slf4j
// 定义 MockServiceProxy 类，实现 InvocationHandler 接口，用于创建模拟服务的动态代理
// 通过 Java 的动态代理机制（InvocationHandler 接口）创建一个模拟服务代理对象。
// 它主要用于在开发或测试场景中，模拟某个接口或类的行为，而无需实现真实的业务逻辑。
public class MockServiceProxy implements InvocationHandler {

    // 重写 invoke 方法，处理代理对象的方法调用
    // 参数 proxy 是代理实例，method 是被调用的方法，args 是方法参数
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        // 获取被调用方法的返回类型
        Class<?> returnType = method.getReturnType();
        // 记录日志，输出被调用的方法名称
        log.info("mock invoke {}", method.getName());
        // 调用 getMockObject 方法，根据返回类型生成默认的模拟对象
        return getMockObject(returnType);
    }

    // 定义私有方法 getMockObject，根据传入的类型返回相应的默认值
    // 参数 type 是方法的返回类型
    private Object getMockObject(Class<?> type) {
        // 判断类型是否为基本数据类型
        if (type.isPrimitive()) {
            // 如果是 boolean 类型，返回默认值 false
            if (type == boolean.class) {
                return false;
                // 如果是 int 类型，返回默认值 0
            } else if (type == int.class) {
                return 0;
                // 如果是 short 类型，返回默认值 0
            } else if (type == short.class) {
                return 0;
                // 如果是 long 类型，返回默认值 0L（长整型）
            } else if (type == long.class) {
                return 0L;
                // 如果是 double 类型，返回默认值 0d（双精度浮点）
            } else if (type == double.class) {
                return 0d;
                // 如果是 char 类型，返回默认值 '0'
            } else if (type == char.class) {
                return '0';
                // 如果是 byte 类型，返回默认值 0
            } else if (type == byte.class) {
                return 0;
                // 如果是 float 类型，返回默认值 0f（单精度浮点）
            } else if (type == float.class) {
                return 0f;
            }
        }

        // 如果是对象类型（非基本类型），返回 null 作为默认值
        return null;
    }
}
