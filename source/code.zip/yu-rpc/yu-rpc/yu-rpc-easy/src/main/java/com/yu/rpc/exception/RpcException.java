package com.yu.rpc.exception;

public class RpcException extends RuntimeException {
    public RpcException(String message) {
        super(message);
    }
}
