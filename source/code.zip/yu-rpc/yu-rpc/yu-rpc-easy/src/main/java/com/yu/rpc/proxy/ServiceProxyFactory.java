package com.yu.rpc.proxy;

import com.yu.rpc.RpcApplication;

import java.lang.reflect.Proxy;

//服务代理工厂，用于创建对象
public class ServiceProxyFactory {
    public static <T> T getProxy(Class<T> serviceClass){
        if(RpcApplication.getRpcConfig().getMock()){
            return mockProxy(serviceClass);
        }
        return (T) Proxy.newProxyInstance(
                serviceClass.getClassLoader(),
                new Class[]{serviceClass},
                new ServiceProxy()
        );

    }

    public static <T> T mockProxy(Class<T> serviceClass) {
        return (T) Proxy.newProxyInstance(
                serviceClass.getClassLoader(),
                new Class[]{serviceClass},
                new MockServiceProxy()
        );
    }
}
