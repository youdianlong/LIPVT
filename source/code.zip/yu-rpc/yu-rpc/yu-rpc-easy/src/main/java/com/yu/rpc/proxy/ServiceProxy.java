package com.yu.rpc.proxy;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import com.yu.rpc.RpcApplication;
import com.yu.rpc.factory.SingletonFactory;
import com.yu.rpc.loadbalancer.LoadBalancer;
import com.yu.rpc.loadbalancer.LoadBalancerFactory;
import com.yu.rpc.model.RpcRequest;
import com.yu.rpc.model.RpcResponse;
import com.yu.rpc.model.ServiceMetaInfo;
import com.yu.rpc.protocol.ProtocolMessage;
import com.yu.rpc.registry.CaffeineServiceCache;
import com.yu.rpc.registry.Registry;
import com.yu.rpc.registry.RegistryFactory;
import com.yu.rpc.serializer.JdkSerializer;
import com.yu.rpc.serializer.Serializer;
import com.yu.rpc.serializer.SerializerFactory;
import com.yu.rpc.transport.client.NettyTcpClient;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@Slf4j
//为服务实现动态代理，JDK 动态代理
public class ServiceProxy implements InvocationHandler {

    private final NettyTcpClient client;

    public ServiceProxy() {
        client = SingletonFactory.getInstance(NettyTcpClient.class);
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        RpcRequest rpcRequest = RpcRequest.builder()
                .serviceName(method.getDeclaringClass().getName())
                .methodName(method.getName())
                .parameterTypes(method.getParameterTypes())
                .parameters(args)
                .build();

        ServiceMetaInfo metaInfo = ServiceMetaInfo.builder()
                .serviceName(method.getDeclaringClass().getName())
                .build();
        Registry registry = RegistryFactory.getInstance(RpcApplication.getRpcConfig().getRegistryConfig().getRegistry());
        List<ServiceMetaInfo> serviceMetaInfos = registry.serviceDiscovery(metaInfo.getServiceKey());
        if (CollUtil.isEmpty(serviceMetaInfos)) {
            log.error("No service address is available. ServiceKey: [{}]", metaInfo.getServiceKey());
            return null;
        }

        if (CollUtil.isEmpty(serviceMetaInfos)) {
            log.error("No service address is available. ServiceKey: [{}]", metaInfo.getServiceKey());
            return null;
        }


        //负载均衡
        LoadBalancer loadBalancer = LoadBalancerFactory.getInstance(RpcApplication.getRpcConfig().getLoadBalancer());
        Map<String, Object> map = new HashMap<>();
        ServiceMetaInfo serviceMetaInfo = loadBalancer.select(map, serviceMetaInfos);

        //选择需要发送
        CompletableFuture<ProtocolMessage<RpcResponse>> future = (CompletableFuture<ProtocolMessage<RpcResponse>>) client.sendRpcRequest(rpcRequest, serviceMetaInfo);
        // 等待异步任务的完成，并获取结果
        //CompletableFuture 的 get 方法用于等待 CompletableFuture 计算完成并获取其结果。
        // 该方法会阻塞调用线程，直到 CompletableFuture 完成或者当前线程被中断。
        ProtocolMessage<RpcResponse> rpcResponseProtocolMessage = future.get();

        return rpcResponseProtocolMessage.getBody().getData();
    }
}
