package com.yu.rpc.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/*
 * @Description: 服务注册信息
 * @param null
 * @return
 * @Author: yujie
 * @Date: 2025/3/16 17:35
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ServiceRegisterInfo<T> {
    /**
     * 服务名称
     */
    private String serviceName;

    /**
     * 实现类
     */
    private Class<? extends T> implClass;
}
