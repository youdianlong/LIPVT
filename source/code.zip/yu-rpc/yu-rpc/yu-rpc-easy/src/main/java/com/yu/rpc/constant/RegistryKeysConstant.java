package com.yu.rpc.constant;

public class RegistryKeysConstant {
    String ETCD = "etcd";

    String ZOOKEEPER = "zookeeper";
}
