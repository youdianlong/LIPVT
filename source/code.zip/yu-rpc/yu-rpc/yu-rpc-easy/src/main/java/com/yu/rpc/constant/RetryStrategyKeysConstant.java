package com.yu.rpc.constant;

public class RetryStrategyKeysConstant {
    String NO = "no";
    String FIXED_INTERVAL = "fixedInterval";
}
