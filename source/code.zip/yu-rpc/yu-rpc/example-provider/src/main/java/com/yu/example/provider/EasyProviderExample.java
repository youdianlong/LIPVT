package com.yu.example.provider;

import com.yu.example.common.service.UserService;
import com.yu.rpc.RpcApplication;
import com.yu.rpc.config.RpcConfig;
import com.yu.rpc.model.ServiceMetaInfo;
import com.yu.rpc.registry.LocalRegistry;
import com.yu.rpc.registry.Registry;
import com.yu.rpc.registry.RegistryFactory;
import com.yu.rpc.transport.server.NettyServer;
//import com.yu.rpc.server.VertxHttpServer;

/*
 * @Description: 简易服务提供者
 * @param null
 * @return
 * @Author: yujie
 * @Date: 2025/3/12 20:23
 */
public class EasyProviderExample {
    public static void main(String[] args) {
        RpcApplication.init();
        //本地服务注册
        LocalRegistry.register(UserService.class.getName(),UserServiceImpl.class);
        //提供服务
//        TcpServer httpServer = new NettyServer();
//        httpServer.doStart(9334);


        RpcConfig rpcConfig = RpcApplication.getRpcConfig();

        ServiceMetaInfo metaInfo = ServiceMetaInfo.builder()
                .serviceName(UserService.class.getName())
                .host(rpcConfig.getHost())
                .port(rpcConfig.getPort())
                .build();

        Registry registry = RegistryFactory.getInstance(rpcConfig.getRegistryConfig().getRegistry());
        //etcd服务注册和发现服务，将服务名和对应的视线类全类名注册到etcd上
        registry.register(metaInfo);
        new NettyServer().doStart(Integer.parseInt(rpcConfig.getPort()));

    }
}
