package com.yu.example.provider;

import com.yu.example.common.service.UserService;
import com.yu.rpc.bootstrap.ProviderBootstrap;
import com.yu.rpc.model.ServiceRegisterInfo;

import java.util.ArrayList;
import java.util.List;

public class Provider {
    public static void main(String[] args) {
        //要注册的服务
        List<ServiceRegisterInfo<?>> list = new ArrayList<>();
        ServiceRegisterInfo<Object> serviceRegisterInfo = ServiceRegisterInfo.builder()
                .serviceName(UserService.class.getName())
                .implClass(UserServiceImpl.class)
                .build();
        list.add(serviceRegisterInfo);

        ProviderBootstrap.init(list);
    }
}
