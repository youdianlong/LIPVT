package com.yu.serviceserverspringboot;

import com.yu.rpcspringbootstarter.annotation.EnablePrc;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnablePrc
public class ServiceServerSpringbootApplication {

    public static void main(String[] args) {

        SpringApplication.run(ServiceServerSpringbootApplication.class, args);
    }
}
