package com.yu.serviceserverspringboot.service;

import com.yu.example.common.model.User;
import com.yu.example.common.service.UserService;
import com.yu.rpcspringbootstarter.annotation.RpcService;
import org.springframework.stereotype.Component;

@Component
@RpcService
public class UserServiceImpl implements UserService {

    public User getUser(User user) {
        System.out.println("用户名："+user.getName());
        return user;
    }
}
