import com.yu.serviceconsumerspringboot.ConsumerExample;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = com.yu.serviceconsumerspringboot.ServiceConsumerSpringbootApplication.class)
public class ConsumerTest {
    @Autowired
    ConsumerExample consumerExample;

    @Test
    public void test(){
        consumerExample.test();
    }
}
