package com.yu.serviceconsumerspringboot;

import com.yu.rpcspringbootstarter.annotation.EnablePrc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnablePrc(needServer = false)
public class ServiceConsumerSpringbootApplication {

	public static void main(String[] args) {

		SpringApplication.run(ServiceConsumerSpringbootApplication.class, args);

	}

}
