package com.yu.serviceconsumerspringboot;

import com.yu.example.common.model.User;
import com.yu.example.common.service.UserService;
import com.yu.rpcspringbootstarter.annotation.RpcReference;
import org.springframework.stereotype.Service;


@Service
public class ConsumerExample {

    @RpcReference
    private UserService userService;

    public void test() {
        for (int i = 0; i < 3; i++) {
            User user = new User();
            user.setName("yujie"+i);
            System.out.println(userService.getUser(user));
        }
    }

}
